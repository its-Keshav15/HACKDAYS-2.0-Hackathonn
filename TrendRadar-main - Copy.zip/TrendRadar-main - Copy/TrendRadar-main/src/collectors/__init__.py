"""Public social platform collectors."""
