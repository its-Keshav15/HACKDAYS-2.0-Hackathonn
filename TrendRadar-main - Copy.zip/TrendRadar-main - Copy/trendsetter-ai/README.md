# TrendSetter AI 🚀

> **AI-Powered Trend Intelligence, Opportunity Scoring & Viral Content Engine**  
> Built for Creators, Growth Teams, and Marketers to spot breakout trends early and generate high-converting content across platforms.

---

## 🎯 Hackathon Workstreams

TrendSetter AI is built on three core pillars:

1. **Trend Intelligence (`backend/app/services/trend_radar.py`)**
   - Collects, filters, and standardizes multi-platform trend data across **X (Twitter)**, **Reddit**, **TikTok**, **Google Trends**, and **Hacker News**.
   - Computes 24-hour velocity growth, engagement volume, sentiment analysis, and category tagging.
   - Includes high-fidelity mock data and modular adapter interfaces for live TrendRadar and external APIs.

2. **AI Backend (`backend/`)**
   - High-performance asynchronous API built with **Python**, **FastAPI**, and **Uvicorn**.
   - Integrates **Google Gemini API** (`gemini-1.5-flash`) for deep trend catalysts analysis, demographic profiling, and viral content ideation.
   - Built-in multi-factor **Opportunity Scorer** evaluating Reach Potential, Audience Engagement, Monetization Viability, and Execution Speed (0–100 score).
   - **Zero-Failure Mock Fallback Engine**: If no Gemini API key is configured, the system provides high-fidelity heuristic intelligence so the entire app works seamlessly offline or during quick demos.

3. **Frontend (`frontend/`)**
   - Interactive, dark-themed creator dashboard built with **React** and **Vite**.
   - Real-time search, category filters, and platform chips.
   - Visual **Opportunity Scorecard** modal with circular gauge and breakdown metrics.
   - **AI Content Studio** for generating platform-specific hooks, outline blueprints, and CTAs (Shorts/TikTok, X Threads, LinkedIn Carousels, Newsletters) with 1-click clipboard copying.

---

## 📁 Project Directory Structure

```text
trendsetter-ai/
├── .env.example              # Root environment configuration template
├── .gitignore                 # Git ignore rules for Python, Node, Vite
├── README.md                  # Complete documentation and setup guide
│
├── backend/                   # Python FastAPI Backend
│   ├── .env.example           # Backend environment template
│   ├── requirements.txt       # Python dependencies (FastAPI, Gemini, etc.)
│   ├── main.py                # FastAPI server entrypoint
│   ├── config.py              # Environment configuration loader
│   ├── app/
│   │   ├── models/
│   │   │   ├── __init__.py
│   │   │   └── schemas.py     # Pydantic data schemas
│   │   ├── services/
│   │   │   ├── __init__.py
│   │   │   ├── trend_radar.py         # Trend Intelligence & TrendRadar source
│   │   │   ├── opportunity_scorer.py  # Algorithmic scoring engine
│   │   │   └── gemini_analyzer.py     # Gemini API integration & fallback
│   │   └── api/
│   │       ├── __init__.py    # API route aggregator
│   │       ├── trends.py      # /api/trends endpoints
│   │       ├── analysis.py    # /api/trends/{id}/analyze endpoints
│   │       └── ideas.py       # /api/trends/{id}/ideas endpoints
│   └── tests/
│       ├── __init__.py
│       └── test_api.py        # Automated test suite
│
└── frontend/                  # React + Vite Dashboard
    ├── package.json           # Node scripts and dependencies
    ├── vite.config.js         # Vite configuration
    ├── index.html             # HTML shell
    ├── .env.example           # Frontend environment template
    ├── public/
    │   └── favicon.svg        # TrendSetter AI icon
    └── src/
        ├── main.jsx           # React app mount
        ├── App.jsx            # Main dashboard controller
        ├── index.css          # Design system & dark theme styling
        ├── services/
        │   └── api.js         # Backend API client
        └── components/
            ├── Navbar.jsx               # Brand, Gemini status & refresh
            ├── StatsOverview.jsx        # Top metrics cards
            ├── TrendFilters.jsx         # Search and category filters
            ├── TrendCard.jsx            # Individual trend card
            ├── OpportunityModal.jsx     # Visual score gauge & analysis
            └── ContentIdeaGenerator.jsx # AI Content Studio modal
```

---

## ⚡ Quickstart Guide

### Prerequisites
- **Python 3.10+**
- **Node.js 18+** & **npm**

---

### Step 1: Backend Setup & Run

1. Open your terminal and navigate to the `backend/` directory:
   ```bash
   cd backend
   ```

2. (Recommended) Create and activate a virtual environment:
   - **Windows (PowerShell):**
     ```powershell
     python -m venv .venv
     .\.venv\Scripts\Activate.ps1
     ```
   - **macOS / Linux:**
     ```bash
     python3 -m venv .venv
     source .venv/bin/activate
     ```

3. Install backend dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Configure environment variables:
   ```bash
   cp .env.example .env
   ```
   > **Note on Gemini API Key:**  
   > Open `.env` and set `GEMINI_API_KEY=your_key_here`.  
   > You can get a free Gemini API key from [Google AI Studio](https://aistudio.google.com/).  
   > *If left empty, TrendSetter AI automatically operates in intelligent mock mode.*

5. Start the FastAPI backend server:
   ```bash
   uvicorn main:app --reload --port 8000
   ```
   *The backend will be running at [http://localhost:8000](http://localhost:8000).*  
   *Interactive Swagger API documentation is available at [http://localhost:8000/docs](http://localhost:8000/docs).*

6. (Optional) Run automated tests:
   ```bash
   pytest
   ```

---

### Step 2: Frontend Setup & Run

1. In a new terminal window, navigate to the `frontend/` directory:
   ```bash
   cd frontend
   ```

2. (Optional) Create local `.env`:
   ```bash
   cp .env.example .env
   ```

3. Install frontend dependencies:
   ```bash
   npm install
   ```

4. Start the Vite development server:
   ```bash
   npm run dev
   ```
   *The frontend dashboard will be available at [http://localhost:5173](http://localhost:5173).*

---

## 📡 API Reference

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/` | API status and documentation link |
| `GET` | `/api/health` | Health check and Gemini configuration status |
| `GET` | `/api/trends` | List trends with filters (`category`, `platform`, `min_velocity`, `search`) |
| `GET` | `/api/trends/{id}` | Retrieve details for a specific trend |
| `GET` | `/api/trends/{id}/score` | Fast algorithmic opportunity score breakdown |
| `POST` | `/api/trends/{id}/analyze` | Gemini AI deep analysis + refined opportunity score |
| `POST` | `/api/trends/{id}/ideas` | Gemini AI viral content idea generator (hooks, formats, CTAs) |

---

## 🔐 Security & Secrets Management

- **No Secrets in Code**: Secrets are never hardcoded. All keys are loaded dynamically via `python-dotenv` from `.env`.
- `.env` files are ignored by git in [.gitignore](file:///C:/Users/shobh/.gemini/antigravity/scratch/trendsetter-ai/.gitignore).
- Templates with dummy placeholders are provided in [.env.example](file:///C:/Users/shobh/.gemini/antigravity/scratch/trendsetter-ai/.env.example).

---

## 🎬 Hackathon Demo Walkthrough

1. Open **[http://localhost:5173](http://localhost:5173)** in your browser.
2. Observe the **Navbar status badge** confirming whether Gemini API or Mock mode is active.
3. Review the **Stats Overview** showcasing peak growth velocity and attention domains.
4. Use the **Category Chips** (`Tech & AI`, `Creator Economy`, `Business & Startups`) or search for keywords like *"Local AI"* or *"E-Ink"*.
5. Click **"Opportunity Score"** on any trend card:
   - View the animated 0–100 gauge.
   - Inspect the 4-factor breakdown (Reach, Engagement, Monetization, Execution Speed).
   - Read the AI strategic diagnosis and longevity outlook.
6. Click **"AI Studio"**:
   - Customize your target audience (e.g. *Creators & Builders*) and tone.
   - Hit **"Regenerate Ideas"** to produce viral hooks for TikTok/Shorts, X threads, LinkedIn carousels, and newsletters.
   - Click **"Copy All"** to copy ready-to-publish drafts.
