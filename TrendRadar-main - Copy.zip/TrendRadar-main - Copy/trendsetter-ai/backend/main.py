import logging
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from config import settings
from app.api import api_router
from app.models.schemas import HealthResponse

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("trendsetter-ai")

# Initialize FastAPI application
app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="TrendSetter AI: Trend Intelligence, Opportunity Scoring, and Gemini AI Content Ideation Backend."
)

# CORS Middleware to allow requests from React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "*"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routes
app.include_router(api_router, prefix=settings.API_V1_STR)

@app.get("/", tags=["Root"])
def root():
    return {
        "project": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "status": "online",
        "documentation": "/docs",
        "api_v1": settings.API_V1_STR
    }

@app.get(f"{settings.API_V1_STR}/health", response_model=HealthResponse, tags=["Health"])
def health_check():
    from app.services.storage.repository import get_storage_repository
    repo = get_storage_repository()
    return HealthResponse(
        status="healthy",
        gemini_configured=settings.is_gemini_configured,
        gemini_model=settings.GEMINI_MODEL,
        trend_source_mode=settings.TREND_SOURCE_MODE,
        environment=settings.ENVIRONMENT,
        storage_backend=repo.backend_name,
        supabase_configured=settings.is_supabase_configured
    )

if __name__ == "__main__":
    logger.info("Starting TrendSetter AI backend on %s:%s", settings.HOST, settings.PORT)
    uvicorn.run("main:app", host=settings.HOST, port=settings.PORT, reload=True)
