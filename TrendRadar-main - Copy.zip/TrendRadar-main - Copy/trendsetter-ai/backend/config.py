import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env file from backend directory or project root
backend_dir = Path(__file__).resolve().parent
load_dotenv(backend_dir / ".env")
load_dotenv(backend_dir.parent / ".env")

class Settings:
    PROJECT_NAME: str = "TrendSetter AI"
    VERSION: str = "0.3.0"
    API_V1_STR: str = "/api"
    
    # Environment
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "development")
    
    # Server settings
    HOST: str = os.getenv("BACKEND_HOST", "127.0.0.1")
    PORT: int = int(os.getenv("BACKEND_PORT", "8000"))
    
    # AI Engine (Official Google Gemini API)
    # Secrets remain on the backend only and are never sent to the frontend.
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
    GEMINI_MODEL: str = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    GEMINI_TIMEOUT_SECONDS: int = int(os.getenv("GEMINI_TIMEOUT_SECONDS", "30"))
    GEMINI_MAX_OUTPUT_TOKENS: int = int(os.getenv("GEMINI_MAX_OUTPUT_TOKENS", "2048"))
    GEMINI_CACHE_TTL_SECONDS: int = int(os.getenv("GEMINI_CACHE_TTL_SECONDS", "600"))
    
    # Trend Intelligence Mode
    TREND_SOURCE_MODE: str = os.getenv("TREND_SOURCE_MODE", "mock")

    # Supabase / PostgreSQL Persistence
    # When unconfigured or unreachable, automatically falls back to local demo storage.
    SUPABASE_URL: str = os.getenv("SUPABASE_URL", "")
    SUPABASE_KEY: str = os.getenv("SUPABASE_KEY", "")
    SUPABASE_SERVICE_ROLE_KEY: str = os.getenv("SUPABASE_SERVICE_ROLE_KEY", "")
    STORAGE_MODE: str = os.getenv("STORAGE_MODE", "auto")  # 'auto', 'supabase', 'local-demo'
    STORAGE_TIMEOUT_SECONDS: int = int(os.getenv("STORAGE_TIMEOUT_SECONDS", "10"))
    DEFAULT_USER_ID: str = os.getenv("DEFAULT_USER_ID", "demo-user")
    
    @property
    def is_gemini_configured(self) -> bool:
        return bool(self.GEMINI_API_KEY and self.GEMINI_API_KEY.strip() not in {"", "your_gemini_api_key_here"})

    @property
    def is_supabase_configured(self) -> bool:
        url = self.SUPABASE_URL.strip()
        key = self.SUPABASE_KEY.strip()
        invalid_markers = {"", "your_supabase_url_here", "your_supabase_anon_key_here"}
        return bool(url and key and url not in invalid_markers and key not in invalid_markers)

settings = Settings()
