from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field

# ==============================================================================
# Trend Data Schemas
# ==============================================================================

class TrendItem(BaseModel):
    id: str = Field(..., description="Unique identifier for the trend topic")
    title: str = Field(..., description="Headline / Name of the trending topic")
    description: str = Field(..., description="Concise context on what is happening")
    category: str = Field(..., description="Domain category, e.g., Tech & AI, Creator Economy, Business, Pop Culture")
    platform: str = Field(..., description="Primary originating platform (X, Reddit, TikTok, Google Trends, Hacker News)")
    velocity: int = Field(..., description="Percentage growth rate over last 24h, e.g. 185")
    volume: str = Field(..., description="Formatted volume count, e.g., '142K posts'")
    sentiment: str = Field(..., description="Sentiment indicator: 'positive', 'neutral', 'controversial'")
    tags: List[str] = Field(default_factory=list, description="Associated keyword tags")
    source_url: Optional[str] = Field(default=None, description="External reference URL if available")
    first_detected: str = Field(..., description="Human-readable detection time (e.g., '2 hours ago')")
    raw_score: Optional[int] = Field(default=None, description="Heuristic baseline score")


class TrendListResponse(BaseModel):
    total: int
    categories: List[str]
    platforms: List[str]
    trends: List[TrendItem]
    source_mode: str


# ==============================================================================
# Deterministic Opportunity Engine Schemas
# ==============================================================================

class OpportunityScore(BaseModel):
    reach_potential: int = Field(..., ge=0, le=100, description="Estimated audience reach ceiling (0-100)")
    engagement_depth: int = Field(..., ge=0, le=100, description="Expected user discussion and engagement (0-100)")
    monetization_score: int = Field(..., ge=0, le=100, description="Affiliate, sponsorship, or product conversion potential (0-100)")
    execution_speed: int = Field(..., ge=0, le=100, description="How quickly content can be produced (0-100)")
    overall_score: int = Field(..., ge=0, le=100, description="Weighted composite opportunity score (0-100)")
    recommendation: str = Field(..., description="Actionable headline recommendation")
    rationale: str = Field(..., description="Strategic reasoning behind the scoring")


# ==============================================================================
# AI Service Output Schemas (Grounded & Separated Facts vs Interpretations)
# ==============================================================================

class ObservedFacts(BaseModel):
    """
    Factual context strictly grounded in verified input data.
    Never invents metrics, search volume, citations, or external URLs.
    """
    metrics_summary: str = Field(..., description="Direct summary of verified metrics (platform, volume, velocity, sentiment)")
    source_links: List[str] = Field(default_factory=list, description="Source URLs strictly present in the provided evidence")
    evidence_snippets: List[str] = Field(default_factory=list, description="Direct excerpts/factual context from supplied trend data")
    is_evidence_sufficient: bool = Field(..., description="Whether supplied evidence provides adequate basis for high-confidence conclusions")
    evidence_limitations: str = Field(..., description="Explicit description of evidence limitations, gaps, or lack of external links")


class ModelInterpretations(BaseModel):
    """
    Model-generated analytical deductions, clearly distinguished from observed facts.
    """
    growth_catalysts: str = Field(..., description="Capability 1: Why the trend may be growing (catalysts & virality triggers)")
    evidence_summary: str = Field(..., description="Capability 2: Analytical summary of the evidence context")
    intended_audience: List[str] = Field(..., description="Capability 3: Key demographics or target creator personas")
    target_niche: str = Field(..., description="Capability 3: Specific market niche or specialized domain")
    keywords_and_topics: List[str] = Field(..., description="Capability 4: Relevant keywords, search terms, and related topics")
    saturation_and_competition_risks: str = Field(..., description="Capability 7: Explanation of saturation levels and creator competition risks")
    practical_recommended_action: str = Field(..., description="Capability 8: Practical, concrete recommended next step for the creator")


class TrendAnalysisResult(BaseModel):
    """
    Comprehensive structured trend analysis output.
    Preserves the Opportunity Engine's deterministic score without alteration.
    """
    trend_id: str
    topic: str
    observed_facts: ObservedFacts
    interpretations: ModelInterpretations
    opportunity_score: OpportunityScore = Field(..., description="Deterministic score directly from Opportunity Engine (Gemini cannot modify this score)")
    provider: str = Field(..., description="'gemini' or 'fallback-heuristic'")
    is_fallback: bool = Field(default=False, description="True if heuristic fallback was used")
    fallback_reason: Optional[str] = Field(default=None, description="Diagnostic reason if fallback was engaged")
    cached: bool = Field(default=False, description="True if served from response cache")


# Legacy analysis models (for backward compatibility with React OpportunityModal)
class TrendAnalysis(BaseModel):
    why_trending: str = Field(..., description="Root catalyst for the current momentum")
    target_audience: List[str] = Field(..., description="Key demographics or communities interested in this topic")
    longevity_outlook: str = Field(..., description="'Flash in the Pan' (24-48h), 'Sustained Trend' (weeks), or 'Structural Shift' (months)")
    saturation_level: str = Field(..., description="'Early Wave' (Best), 'Peak Attention' (Competitive), or 'Over-Saturated'")
    key_takeaway: str = Field(..., description="The single most important strategic takeaway")


class AnalysisResponse(BaseModel):
    trend_id: str
    topic: str
    analysis: TrendAnalysis
    opportunity_score: OpportunityScore
    generated_by: str = Field(..., description="'gemini' or 'mock-engine'")
    observed_facts: Optional[ObservedFacts] = None
    interpretations: Optional[ModelInterpretations] = None
    is_fallback: bool = False
    fallback_reason: Optional[str] = None
    cached: bool = False


# ==============================================================================
# Content Generation Schemas (Capabilities 5 & 6)
# ==============================================================================

class PlatformContentItem(BaseModel):
    """
    Structured content blueprint for a specific platform.
    Covers YouTube, Instagram, LinkedIn, and Blogs.
    """
    platform: str = Field(..., description="Platform: 'YouTube', 'Instagram', 'LinkedIn', or 'Blog'")
    title: str = Field(..., description="Catchy, high-converting title / headline")
    hook: str = Field(..., description="3-second opening hook or irresistible lead sentence")
    angle: str = Field(..., description="Unique narrative angle or positioning")
    outline: List[str] = Field(..., description="Structured bullet breakdown or script outline")
    call_to_action: str = Field(..., description="High-converting call to action")


class ContentGenerationResult(BaseModel):
    """
    Structured multi-platform content ideas for creators.
    """
    trend_id: Optional[str] = None
    topic: str
    observed_context: str = Field(..., description="Factual context supplied as grounding")
    content_by_platform: List[PlatformContentItem] = Field(..., description="Tailored content for YouTube, Instagram, LinkedIn, and Blogs")
    provider: str = Field(..., description="'gemini' or 'fallback-heuristic'")
    is_fallback: bool = False
    fallback_reason: Optional[str] = None
    cached: bool = False


# Legacy content idea models (for backward compatibility with React ContentIdeaGenerator)
class ContentIdea(BaseModel):
    platform: str
    hook: str
    angle: str
    outline: List[str]
    call_to_action: str
    estimated_viral_factor: Optional[str] = "High"
    title: Optional[str] = None


class ContentIdeaRequest(BaseModel):
    target_audience: Optional[str] = Field(default="Creators & Tech Professionals")
    tone: Optional[str] = Field(default="Insightful & High-Energy")
    custom_angle: Optional[str] = Field(default=None)


class ContentIdeasResponse(BaseModel):
    trend_id: str
    topic: str
    ideas: List[ContentIdea]
    generated_by: str
    observed_context: Optional[str] = None
    is_fallback: bool = False
    cached: bool = False


# ==============================================================================
# Request Payloads
# ==============================================================================

class TrendAnalyzeRequest(BaseModel):
    trend_id: Optional[str] = Field(default=None, description="Trend ID to look up and analyze")
    trend: Optional[TrendItem] = Field(default=None, description="Optional inline trend object to analyze")


class ContentGenerateRequest(BaseModel):
    trend_id: Optional[str] = Field(default=None, description="Trend ID to generate content for")
    trend: Optional[TrendItem] = Field(default=None, description="Optional inline trend object")
    platforms: Optional[List[str]] = Field(
        default_factory=lambda: ["YouTube", "Instagram", "LinkedIn", "Blog"],
        description="Target platforms to generate content for"
    )
    target_audience: Optional[str] = Field(default=None, description="Target creator audience persona")
    tone: Optional[str] = Field(default=None, description="Desired editorial tone")


# ==============================================================================
# Health Schema
# ==============================================================================

class HealthResponse(BaseModel):
    status: str
    gemini_configured: bool
    gemini_model: str
    trend_source_mode: str
    environment: str
    storage_backend: Optional[str] = "local-demo"
    supabase_configured: Optional[bool] = False


# ==============================================================================
# Supabase / PostgreSQL Persistence Schemas
# ==============================================================================

class SavedTrendCreate(BaseModel):
    trend_id: str = Field(..., description="Unique trend identifier, e.g. 'trend-01'")
    title: str = Field(..., description="Headline of the trend topic")
    category: str = Field(..., description="Domain category")
    platform: str = Field(..., description="Originating platform")
    velocity: int = Field(default=0, description="24h growth velocity percentage")
    volume: Optional[str] = Field(default=None, description="Volume count")
    sentiment: Optional[str] = Field(default=None, description="Sentiment label")
    source_url: Optional[str] = Field(default=None, description="External verification URL if available")
    notes: Optional[str] = Field(default=None, description="Optional creator notes")


class SavedTrendItem(BaseModel):
    id: str = Field(..., description="UUID identifier")
    user_id: str = Field(..., description="User or demo identity")
    trend_id: str = Field(..., description="Referenced trend identifier")
    title: str
    category: str
    platform: str
    velocity: int
    volume: Optional[str] = None
    sentiment: Optional[str] = None
    source_url: Optional[str] = None
    notes: Optional[str] = None
    created_at: str
    updated_at: str


class SavedTrendListResponse(BaseModel):
    total: int
    items: List[SavedTrendItem]
    storage_backend: str = Field(..., description="'supabase' or 'local-demo'")


class UserPreferencesUpdate(BaseModel):
    niche: Optional[str] = Field(default=None, description="Creator niche, e.g. 'B2B SaaS Growth'")
    audience: Optional[str] = Field(default=None, description="Target demographic, e.g. 'Early Founders'")
    preferred_platform: Optional[str] = Field(default=None, description="Primary platform, e.g. 'LinkedIn' or 'YouTube'")


class UserPreferencesItem(BaseModel):
    id: str
    user_id: str
    niche: Optional[str] = None
    audience: Optional[str] = None
    preferred_platform: Optional[str] = None
    created_at: str
    updated_at: str


class TrendHistoryItem(BaseModel):
    id: str
    trend_id: str
    topic: Optional[str] = None
    platform: Optional[str] = None
    velocity: int = 0
    volume: Optional[str] = None
    sentiment: Optional[str] = None
    raw_score: Optional[int] = None
    observed_at: str
    created_at: str


class UserAlertCreate(BaseModel):
    topic_or_keyword: str = Field(..., description="Keyword or topic to monitor")
    category: Optional[str] = Field(default=None, description="Optional domain category filter")
    min_velocity: int = Field(default=100, description="Velocity threshold to trigger alert")


class UserAlertItem(BaseModel):
    id: str
    user_id: str
    topic_or_keyword: str
    category: Optional[str] = None
    min_velocity: int
    is_active: bool
    last_triggered_at: Optional[str] = None
    created_at: str
    updated_at: str


class StorageStatusResponse(BaseModel):
    storage_backend: str
    supabase_configured: bool
    is_connected: bool
    error_detail: Optional[str] = None
