from app.models.schemas import TrendItem, OpportunityScore

class OpportunityScorer:
    """
    Computes algorithmic multi-dimensional opportunity scores for trending topics.
    Can be used standalone or as baseline priors for Gemini AI refinement.
    """
    
    CATEGORY_MONETIZATION_WEIGHTS = {
        "Tech & AI": 92,
        "Business & Startups": 95,
        "Creator Economy": 86,
        "Pop Culture": 68,
        "Gaming & Pop Culture": 74,
    }

    @classmethod
    def calculate_score(cls, trend: TrendItem) -> OpportunityScore:
        # 1. Reach Potential (0-100): Weighted by velocity
        # Higher velocity indicates viral surge momentum
        reach = min(98, max(35, int(45 + (trend.velocity * 0.16))))

        # 2. Engagement Depth (0-100): Based on sentiment & platform
        sentiment_bonus = 10 if trend.sentiment == "positive" else (15 if trend.sentiment == "controversial" else 0)
        platform_base = 80 if trend.platform in ["TikTok", "Reddit"] else 72
        engagement = min(96, platform_base + sentiment_bonus)

        # 3. Monetization Viability (0-100)
        monetization = cls.CATEGORY_MONETIZATION_WEIGHTS.get(trend.category, 70)

        # 4. Execution Speed (0-100): How fast creators can jump on it
        execution = 88 if trend.platform in ["TikTok", "X"] else 75

        # 5. Composite Weighted Score
        overall = int(
            (reach * 0.35) +
            (engagement * 0.25) +
            (monetization * 0.25) +
            (execution * 0.15)
        )

        # Actionable recommendation
        if overall >= 85:
            recommendation = "High Priority Viral Window: Ship content within 6-12 hours."
            rationale = f"Velocity is spiking at +{trend.velocity}% with exceptional reach potential. Audience attention is actively peaking."
        elif overall >= 75:
            recommendation = "Strong Emerging Opportunity: Great 24-48h publishing window."
            rationale = f"Steady positive traction with robust engagement across {trend.platform}. High conversion for targeted niche audiences."
        else:
            recommendation = "Selective Niche Play: Target specialized sub-audiences only."
            rationale = "Decent baseline conversation, but competitive saturation or narrower audience limits breakout broad appeal."

        return OpportunityScore(
            reach_potential=reach,
            engagement_depth=engagement,
            monetization_score=monetization,
            execution_speed=execution,
            overall_score=overall,
            recommendation=recommendation,
            rationale=rationale
        )
