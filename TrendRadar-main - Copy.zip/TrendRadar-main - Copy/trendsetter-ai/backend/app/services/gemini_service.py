import json
import logging
import time
from typing import List, Optional, Dict, Any, Tuple
from config import settings
from app.models.schemas import (
    TrendItem,
    OpportunityScore,
    ObservedFacts,
    ModelInterpretations,
    TrendAnalysisResult,
    PlatformContentItem,
    ContentGenerationResult,
    TrendAnalysis,
    AnalysisResponse,
    ContentIdea,
    ContentIdeasResponse,
    ContentIdeaRequest,
    ContentGenerateRequest
)
from app.services.opportunity_scorer import OpportunityScorer

logger = logging.getLogger("trendsetter-ai.gemini_service")

# Detect official google-genai SDK
try:
    from google import genai
    from google.genai import types
    from google.genai import errors as genai_errors
    GENAI_SDK_AVAILABLE = True
except ImportError:
    genai = None
    types = None
    genai_errors = None
    GENAI_SDK_AVAILABLE = False
    logger.warning("Official 'google-genai' SDK not found.")

# Detect legacy google-generativeai SDK as secondary fallback
try:
    import google.generativeai as legacy_genai
    LEGACY_GENAI_AVAILABLE = True
except ImportError:
    legacy_genai = None
    LEGACY_GENAI_AVAILABLE = False


class GeminiTrendAIService:
    """
    Separate AI Service integrating the official Google Gemini API into TrendSetter AI.
    
    Provides:
    1. Trend growth explanations and catalysts.
    2. Evidence summaries and verified source links.
    3. Target audience personas and specific niche identification.
    4. Relevant keywords and related topics.
    5. Platform content blueprints for YouTube, Instagram, LinkedIn, and Blogs.
    6. Platform-specific titles, hooks, outlines, and calls to action.
    7. Saturation and creator competition risk analysis.
    8. Practical, concrete recommended next actions for creators.
    
    Adheres strictly to grounding rules:
    - Never invents search volume, engagement metrics, citations or URLs.
    - Explicitly marks when evidence is insufficient.
    - Clearly separates observed facts from model interpretations.
    - Respects deterministic Opportunity Engine scores without silent modification.
    - Provides a labeled, graceful heuristic fallback if API is unavailable.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model_name: Optional[str] = None,
        client: Optional[Any] = None,
        timeout_seconds: Optional[int] = None,
        max_output_tokens: Optional[int] = None,
        cache_ttl_seconds: Optional[int] = None
    ):
        self.api_key = api_key if api_key is not None else settings.GEMINI_API_KEY
        self.model_name = model_name or settings.GEMINI_MODEL
        self.timeout = timeout_seconds or settings.GEMINI_TIMEOUT_SECONDS
        self.max_tokens = max_output_tokens or settings.GEMINI_MAX_OUTPUT_TOKENS
        self.cache_ttl = cache_ttl_seconds or settings.GEMINI_CACHE_TTL_SECONDS
        
        # In-memory TTL cache: key -> (timestamp, data)
        self._cache: Dict[str, Tuple[float, Any]] = {}
        
        # Client initialization
        if client is not None:
            self.client = client
            self.client_type = "custom"
            logger.info("Gemini AI Service initialized with custom/mock client.")
        else:
            self.client, self.client_type = self._init_client()

    def _init_client(self) -> Tuple[Optional[Any], str]:
        """Initialize the official Google GenAI client if API key is configured."""
        if not self._is_key_valid():
            logger.info("Gemini API key not configured. Operating in heuristic fallback mode.")
            return None, "none"

        # 1. Prefer modern official google-genai SDK
        if GENAI_SDK_AVAILABLE:
            try:
                c = genai.Client(api_key=self.api_key)
                logger.info("Initialized official 'google-genai' client (model: %s).", self.model_name)
                return c, "genai"
            except Exception as e:
                logger.error("Failed to initialize 'google-genai' client: %s", e)

        # 2. Secondary fallback to legacy google-generativeai SDK
        if LEGACY_GENAI_AVAILABLE:
            try:
                legacy_genai.configure(api_key=self.api_key)
                model = legacy_genai.GenerativeModel(self.model_name)
                logger.info("Initialized legacy 'google-generativeai' client (model: %s).", self.model_name)
                return model, "legacy"
            except Exception as e:
                logger.error("Failed to initialize legacy 'google-generativeai' client: %s", e)

        return None, "none"

    def _is_key_valid(self) -> bool:
        if not self.api_key:
            return False
        cleaned = self.api_key.strip()
        return bool(cleaned and cleaned != "your_gemini_api_key_here")

    def clear_cache(self) -> None:
        """Clear the in-memory response cache."""
        self._cache.clear()

    # ==========================================================================
    # Trend Analysis Capability (POST /api/trends/analyze)
    # ==========================================================================

    async def analyze_trend(self, trend: TrendItem, force_refresh: bool = False) -> TrendAnalysisResult:
        """
        Analyze a trend using Gemini API, or gracefully fall back to heuristic engine.
        Guarantees that the deterministic Opportunity Engine score is untouched.
        """
        # Always compute deterministic Opportunity Engine baseline score
        deterministic_score = OpportunityScorer.calculate_score(trend)

        # Cache check to avoid redundant API calls
        cache_key = f"analyze:{trend.id}:{trend.velocity}:{trend.volume}:{self.model_name}"
        if not force_refresh and cache_key in self._cache:
            ts, cached_result = self._cache[cache_key]
            if time.time() - ts < self.cache_ttl:
                logger.debug("Cache hit for trend analysis: %s", trend.id)
                # Clone result with cached=True
                return cached_result.model_copy(update={"cached": True})

        # Check evidence sufficiency
        is_sufficient, limitations = self._evaluate_evidence(trend)
        verified_source_links = [trend.source_url] if (trend.source_url and trend.source_url.strip()) else []

        # If client is available, attempt Gemini API call
        if self.client:
            try:
                result = await self._call_gemini_analysis(
                    trend=trend,
                    deterministic_score=deterministic_score,
                    is_sufficient=is_sufficient,
                    limitations=limitations,
                    verified_source_links=verified_source_links
                )
                self._cache[cache_key] = (time.time(), result)
                return result
            except Exception as exc:
                err_msg = str(exc)
                logger.warning("Gemini analysis API call failed (%s); engaging heuristic fallback.", err_msg)
                fallback_reason = f"Gemini API error ({type(exc).__name__}): {err_msg[:120]}"
                return self._generate_fallback_analysis(
                    trend=trend,
                    deterministic_score=deterministic_score,
                    is_sufficient=is_sufficient,
                    limitations=limitations,
                    verified_source_links=verified_source_links,
                    reason=fallback_reason
                )

        # Graceful fallback when Gemini is not configured
        return self._generate_fallback_analysis(
            trend=trend,
            deterministic_score=deterministic_score,
            is_sufficient=is_sufficient,
            limitations=limitations,
            verified_source_links=verified_source_links,
            reason="GEMINI_API_KEY is not configured; using deterministic heuristic intelligence"
        )

    async def _call_gemini_analysis(
        self,
        trend: TrendItem,
        deterministic_score: OpportunityScore,
        is_sufficient: bool,
        limitations: str,
        verified_source_links: List[str]
    ) -> TrendAnalysisResult:
        """Invoke Gemini model for trend analysis and parse strictly structured JSON."""
        prompt = f"""You are TrendSetter AI's Chief Trend Intelligence Analyst.
Analyze the following trend and return ONLY a valid JSON object matching the exact schema below.

=== SUPPLIED TREND EVIDENCE (CONTEXT) ===
- ID: {trend.id}
- Title: {trend.title}
- Context/Description: {trend.description[:1500]}
- Category: {trend.category}
- Platform: {trend.platform}
- 24h Velocity Growth: +{trend.velocity}%
- Volume: {trend.volume}
- Sentiment: {trend.sentiment}
- Associated Tags: {', '.join(trend.tags) if trend.tags else 'None'}
- Verified Source URL: {trend.source_url or 'None'}
- First Detected: {trend.first_detected}

=== DETERMINISTIC OPPORTUNITY SCORE (READ-ONLY INPUT) ===
- Reach Potential: {deterministic_score.reach_potential}/100
- Engagement Depth: {deterministic_score.engagement_depth}/100
- Monetization Score: {deterministic_score.monetization_score}/100
- Execution Speed: {deterministic_score.execution_speed}/100
- Overall Score: {deterministic_score.overall_score}/100
- Algorithmic Recommendation: {deterministic_score.recommendation}

=== STRICT FACTUAL GROUNDING RULES ===
1. observed_facts must ONLY contain verifiable facts directly supplied in the context above.
2. source_links: ONLY list the provided Verified Source URL if present ({verified_source_links}). NEVER invent external URLs.
3. NEVER invent search volume numbers, viewer counts, engagement statistics, or citations not explicitly in the context.
4. If evidence is thin or unverified, state this clearly in evidence_limitations and set is_evidence_sufficient to false.
5. In interpretations, provide your analytical reasoning for:
   - growth_catalysts: explain why the trend may be growing
   - evidence_summary: summarize the supplied evidence
   - intended_audience: identify target creator/consumer personas
   - target_niche: specific market niche
   - keywords_and_topics: relevant keywords and related topics
   - saturation_and_competition_risks: explain saturation levels and creator competition risks
   - practical_recommended_action: recommend an immediate practical action for the creator

=== REQUIRED JSON SCHEMA ===
{{
  "observed_facts": {{
    "metrics_summary": "Direct factual summary of verified platform, volume, velocity, and sentiment",
    "source_links": {json.dumps(verified_source_links)},
    "evidence_snippets": ["Key factual excerpt from supplied context"],
    "is_evidence_sufficient": {str(is_sufficient).lower()},
    "evidence_limitations": "{limitations}"
  }},
  "interpretations": {{
    "growth_catalysts": "Why the trend may be growing based on supplied signals",
    "evidence_summary": "Analytical summary of the evidence context",
    "intended_audience": ["Persona 1", "Persona 2", "Persona 3"],
    "target_niche": "Specific sub-niche or domain",
    "keywords_and_topics": ["Keyword 1", "Keyword 2", "Topic 1", "Topic 2"],
    "saturation_and_competition_risks": "Assessment of creator competition and lifecycle saturation",
    "practical_recommended_action": "Specific next action creator should take within 24 hours"
  }}
}}
Return ONLY raw JSON. No markdown fences.
"""

        raw_response_text = await self._execute_model_call(prompt)
        parsed = self._extract_json(raw_response_text)

        # Validate / structure ObservedFacts
        facts_data = parsed.get("observed_facts", {})
        # Force strict filtering on source links: only allow URLs that were in verified_source_links
        model_links = facts_data.get("source_links", [])
        clean_links = [link for link in model_links if link in verified_source_links] if verified_source_links else []

        observed_facts = ObservedFacts(
            metrics_summary=facts_data.get("metrics_summary") or f"Platform: {trend.platform}, Volume: {trend.volume}, Velocity: +{trend.velocity}%, Sentiment: {trend.sentiment}",
            source_links=clean_links,
            evidence_snippets=facts_data.get("evidence_snippets") or [trend.description],
            is_evidence_sufficient=bool(facts_data.get("is_evidence_sufficient", is_sufficient)),
            evidence_limitations=facts_data.get("evidence_limitations") or limitations
        )

        # Validate / structure ModelInterpretations
        interp_data = parsed.get("interpretations", {})
        interpretations = ModelInterpretations(
            growth_catalysts=interp_data.get("growth_catalysts") or f"Momentum driven by organic interest on {trend.platform} with +{trend.velocity}% growth velocity.",
            evidence_summary=interp_data.get("evidence_summary") or f"Evidence confirms active discussions regarding '{trend.title}' on {trend.platform}.",
            intended_audience=interp_data.get("intended_audience") or [f"{trend.category} Creators", "Digital Strategists"],
            target_niche=interp_data.get("target_niche") or trend.category,
            keywords_and_topics=interp_data.get("keywords_and_topics") or trend.tags,
            saturation_and_competition_risks=interp_data.get("saturation_and_competition_risks") or "Early-to-mid stage momentum with moderate competitive crowding.",
            practical_recommended_action=interp_data.get("practical_recommended_action") or f"Produce a focused breakdown of '{trend.title}' highlighting hands-on utility."
        )

        # Strict constraint: Gemini cannot change the deterministic opportunity score
        return TrendAnalysisResult(
            trend_id=trend.id,
            topic=trend.title,
            observed_facts=observed_facts,
            interpretations=interpretations,
            opportunity_score=deterministic_score,
            provider="gemini",
            is_fallback=False,
            cached=False
        )

    # ==========================================================================
    # Content Generation Capability (POST /api/content/generate)
    # ==========================================================================

    async def generate_content(
        self,
        trend: TrendItem,
        req: ContentGenerateRequest,
        force_refresh: bool = False
    ) -> ContentGenerationResult:
        """
        Generate content blueprints across YouTube, Instagram, LinkedIn, and Blogs.
        """
        target_platforms = req.platforms or ["YouTube", "Instagram", "LinkedIn", "Blog"]
        audience = req.target_audience or f"Creators & Professionals in {trend.category}"
        tone = req.tone or "Punchy, insightful, high-converting, and actionable"

        cache_key = f"content:{trend.id}:{','.join(sorted(target_platforms))}:{audience}:{tone}:{self.model_name}"
        if not force_refresh and cache_key in self._cache:
            ts, cached_result = self._cache[cache_key]
            if time.time() - ts < self.cache_ttl:
                logger.debug("Cache hit for content generation: %s", trend.id)
                return cached_result.model_copy(update={"cached": True})

        observed_context = (
            f"Topic: {trend.title} | Platform Origin: {trend.platform} | Velocity: +{trend.velocity}% | "
            f"Volume: {trend.volume} | Sentiment: {trend.sentiment} | Evidence: {trend.description}"
        )

        if self.client:
            try:
                result = await self._call_gemini_content(
                    trend=trend,
                    target_platforms=target_platforms,
                    audience=audience,
                    tone=tone,
                    observed_context=observed_context
                )
                self._cache[cache_key] = (time.time(), result)
                return result
            except Exception as exc:
                err_msg = str(exc)
                logger.warning("Gemini content generation API call failed (%s); engaging heuristic fallback.", err_msg)
                return self._generate_fallback_content(
                    trend=trend,
                    target_platforms=target_platforms,
                    audience=audience,
                    tone=tone,
                    observed_context=observed_context,
                    reason=f"Gemini API error ({type(exc).__name__}): {err_msg[:120]}"
                )

        return self._generate_fallback_content(
            trend=trend,
            target_platforms=target_platforms,
            audience=audience,
            tone=tone,
            observed_context=observed_context,
            reason="GEMINI_API_KEY is not configured; using deterministic heuristic content blueprints"
        )

    async def _call_gemini_content(
        self,
        trend: TrendItem,
        target_platforms: List[str],
        audience: str,
        tone: str,
        observed_context: str
    ) -> ContentGenerationResult:
        """Call Gemini to generate platform content blueprints."""
        prompt = f"""You are TrendSetter AI's Chief Viral Content Strategist.
Generate tailored, high-converting content blueprints for each of the requested platforms: {', '.join(target_platforms)}.

=== SUPPLIED TREND CONTEXT ===
{observed_context}
Category: {trend.category}
Target Audience Persona: {audience}
Editorial Tone: {tone}

=== STRICT GROUNDING RULES ===
- Ground your ideas in the supplied topic context.
- NEVER hallucinate made-up research citations, non-existent URLs, or fabricated numerical stats.
- Provide tailored blueprints for each platform in the requested list: {target_platforms}.
- For each platform include:
  - platform: Name of platform ('YouTube', 'Instagram', 'LinkedIn', or 'Blog')
  - title: Irresistible, high-converting title / headline
  - hook: 3-second opening hook or opening sentence
  - angle: Unique perspective or framing
  - outline: Array of 3-5 structured steps or script bullet points
  - call_to_action: Specific engagement, comment, or lead generation prompt

=== REQUIRED JSON SCHEMA ===
[
  {{
    "platform": "YouTube",
    "title": "High-CTR YouTube Title",
    "hook": "Opening hook",
    "angle": "Contrarian breakdown or tutorial",
    "outline": ["0:00 Hook", "1:00 Problem", "3:00 Solution", "5:00 Takeaway"],
    "call_to_action": "Subscribe and comment for checklist"
  }}
]
Return ONLY a valid JSON array of objects. No markdown formatting.
"""

        raw_response_text = await self._execute_model_call(prompt)
        parsed_array = self._extract_json(raw_response_text)
        if not isinstance(parsed_array, list):
            parsed_array = [parsed_array]

        items: List[PlatformContentItem] = []
        for obj in parsed_array:
            try:
                items.append(PlatformContentItem(
                    platform=str(obj.get("platform", "YouTube")),
                    title=str(obj.get("title", f"The Truth About {trend.title}")),
                    hook=str(obj.get("hook", f"Here is why {trend.title} is blowing up right now...")),
                    angle=str(obj.get("angle", "Practical Breakdown")),
                    outline=[str(p) for p in obj.get("outline", ["Introduction", "Core Insight", "Action Plan"])],
                    call_to_action=str(obj.get("call_to_action", "Drop your thoughts below!"))
                ))
            except Exception as e:
                logger.debug("Failed to parse content item: %s", e)

        # Backfill any missing requested platforms from fallback generator
        existing_platforms = {item.platform.lower() for item in items}
        for plat in target_platforms:
            if plat.lower() not in existing_platforms:
                fallback_item = self._create_single_platform_content(trend, plat, audience)
                items.append(fallback_item)

        return ContentGenerationResult(
            trend_id=trend.id,
            topic=trend.title,
            observed_context=observed_context,
            content_by_platform=items,
            provider="gemini",
            is_fallback=False,
            cached=False
        )

    # ==========================================================================
    # Model Call Execution Helper
    # ==========================================================================

    async def _execute_model_call(self, prompt: str) -> str:
        """Execute request against Gemini client with timeout handling."""
        # 1. Custom / Mocked client handling
        if self.client_type == "custom":
            if hasattr(self.client, "generate_content"):
                resp = self.client.generate_content(prompt)
                return getattr(resp, "text", str(resp))
            elif hasattr(self.client, "models") and hasattr(self.client.models, "generate_content"):
                resp = self.client.models.generate_content(model=self.model_name, contents=prompt)
                return getattr(resp, "text", str(resp))
            raise ValueError("Custom client does not implement recognized generate_content interface")

        # 2. Modern google-genai SDK
        if self.client_type == "genai" and self.client:
            config = types.GenerateContentConfig(
                response_mime_type="application/json",
                temperature=0.2,
                max_output_tokens=self.max_tokens,
                http_options=types.HttpOptions(timeout=self.timeout * 1000)
            )
            response = self.client.models.generate_content(
                model=self.model_name,
                contents=prompt,
                config=config
            )
            return response.text or ""

        # 3. Legacy google-generativeai SDK
        if self.client_type == "legacy" and self.client:
            response = self.client.generate_content(prompt)
            return response.text or ""

        raise RuntimeError("No Gemini API client available")

    def _extract_json(self, raw_text: str) -> Any:
        """Strip markdown fences and load JSON safely."""
        text = raw_text.strip()
        if text.startswith("```"):
            lines = text.splitlines()
            if lines and lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            text = "\n".join(lines).strip()
        return json.loads(text)

    # ==========================================================================
    # Evidence Evaluation & Heuristic Fallbacks
    # ==========================================================================

    def _evaluate_evidence(self, trend: TrendItem) -> Tuple[bool, str]:
        """Assess whether trend evidence is sufficient for high-confidence conclusions."""
        has_url = bool(trend.source_url and trend.source_url.strip())
        desc_len = len(trend.description or "")
        
        if desc_len < 25:
            return False, "Evidence is extremely sparse (short description with no corroboration)."
        if not has_url:
            return False, f"Evidence is single-source telemetry from {trend.platform} without an external verification URL."
        return True, f"Verified telemetry with external source URL from {trend.platform}."

    def _generate_fallback_analysis(
        self,
        trend: TrendItem,
        deterministic_score: OpportunityScore,
        is_sufficient: bool,
        limitations: str,
        verified_source_links: List[str],
        reason: str
    ) -> TrendAnalysisResult:
        """Deterministic heuristic fallback when Gemini API is unavailable."""
        audience_map = {
            "Tech & AI": ["AI Engineers & Researchers", "Full-Stack Developers", "Early Tech Adopters", "CTOs & Tech Leads"],
            "Business & Startups": ["Solopreneurs & Indie Hackers", "SaaS Founders", "Growth Marketers", "Angel Investors"],
            "Creator Economy": ["Short-form Video Creators", "YouTubers", "Digital Agency Owners", "Social Strategists"],
            "Pop Culture": ["Digital Culture Commentators", "Lifestyle Influencers", "Gen Z Trend Watchers"],
            "Gaming & Pop Culture": ["Twitch Streamers", "Gaming Content Creators", "Community Discord Leads"]
        }
        audiences = audience_map.get(trend.category, ["Digital Content Creators", "Growth Strategists", "Tech Professionals"])

        saturation = (
            "Early Wave (Prime Window: high velocity surge)" if trend.velocity > 180
            else ("Peak Attention (High Competition: actively trending)" if trend.velocity > 100
            else "Stable / Maturing Topic (Moderate competition)")
        )

        niche = f"{trend.category} - {trend.tags[0]}" if trend.tags else trend.category

        observed_facts = ObservedFacts(
            metrics_summary=f"Origin: {trend.platform} | Velocity: +{trend.velocity}% in 24h | Volume: {trend.volume} | Sentiment: {trend.sentiment}",
            source_links=verified_source_links,
            evidence_snippets=[trend.description] if trend.description else [],
            is_evidence_sufficient=is_sufficient,
            evidence_limitations=limitations
        )

        interpretations = ModelInterpretations(
            growth_catalysts=(
                f"Surge in organic discussion on {trend.platform} driven by '{trend.title}'. "
                f"High-velocity signals (+{trend.velocity}%) indicate growing community resonance and algorithmic amplification."
            ),
            evidence_summary=(
                f"Signals confirm +{trend.velocity}% momentum across {trend.platform} with {trend.sentiment} community sentiment."
            ),
            intended_audience=audiences,
            target_niche=niche,
            keywords_and_topics=list(dict.fromkeys(trend.tags + [trend.title.split()[0], trend.category])),
            saturation_and_competition_risks=(
                f"Current stage is '{saturation}'. Competitor coverage is accelerating; "
                f"creators who ship content within 12-24 hours will capture the primary discovery curve."
            ),
            practical_recommended_action=(
                f"Publish an educational breakdown of '{trend.title}' within 24 hours. "
                f"Focus on practical takeaways or contrarian insights rather than generic recap."
            )
        )

        return TrendAnalysisResult(
            trend_id=trend.id,
            topic=trend.title,
            observed_facts=observed_facts,
            interpretations=interpretations,
            opportunity_score=deterministic_score,
            provider="fallback-heuristic",
            is_fallback=True,
            fallback_reason=reason,
            cached=False
        )

    def _generate_fallback_content(
        self,
        trend: TrendItem,
        target_platforms: List[str],
        audience: str,
        tone: str,
        observed_context: str,
        reason: str
    ) -> ContentGenerationResult:
        """Deterministic heuristic content blueprint generator covering all platforms."""
        items: List[PlatformContentItem] = []
        for plat in target_platforms:
            items.append(self._create_single_platform_content(trend, plat, audience))

        return ContentGenerationResult(
            trend_id=trend.id,
            topic=trend.title,
            observed_context=observed_context,
            content_by_platform=items,
            provider="fallback-heuristic",
            is_fallback=True,
            fallback_reason=reason,
            cached=False
        )

    def _create_single_platform_content(self, trend: TrendItem, platform: str, audience: str) -> PlatformContentItem:
        """Create platform-specific blueprint for YouTube, Instagram, LinkedIn, or Blog."""
        plat_lower = platform.lower()

        if "youtube" in plat_lower:
            return PlatformContentItem(
                platform="YouTube",
                title=f"The Real Reason {trend.title} Is Blowing Up (Deep Dive)",
                hook=f"Everyone is talking about {trend.title}, but almost nobody understands what it actually means for you...",
                angle="First-Principles Deconstruction & Live Demonstration",
                outline=[
                    "0:00 - 0:20: The +{0}% velocity spike on {1} and why this matters today".format(trend.velocity, trend.platform),
                    "0:21 - 1:45: Breakdown of the 3 fundamental catalysts behind the trend",
                    "1:46 - 3:30: Hands-on walkthrough or case study showing how to capitalize",
                    "3:31 - 4:15: Common mistakes to avoid before the market saturates",
                    "4:16 - 5:00: Final takeaway and action plan"
                ],
                call_to_action="Subscribe and comment 'BLUEPRINT' to get our free step-by-step implementation guide."
            )
        elif "instagram" in plat_lower:
            return PlatformContentItem(
                platform="Instagram",
                title=f"Why {trend.title} Changes Everything in 2026",
                hook=f"Stop scrolling: {trend.title} just surged +{trend.velocity}%. Here is what you need to know in 30 seconds:",
                angle="High-Impact Visual Carousel / Reel Breakdown",
                outline=[
                    "Slide 1 / Scene 1: Bold stat headline highlighting +{0}% surge".format(trend.velocity),
                    "Slide 2 / Scene 2: The catalyst that ignited the conversation",
                    "Slide 3 / Scene 3: The 3 biggest winners and losers",
                    "Slide 4 / Scene 4: How creators/builders can implement this today",
                    "Slide 5 / Scene 5: Save this post to refer back to this week"
                ],
                call_to_action="Save this post and share with a friend who needs to see this before it peaks."
            )
        elif "linkedin" in plat_lower:
            return PlatformContentItem(
                platform="LinkedIn",
                title=f"Strategic Analysis: What the Rise of {trend.title} Tells Us About {trend.category}",
                hook=f"{trend.title} is not just hype—it represents a structural inflection in how {trend.category} operates.",
                angle="Executive Strategic Synthesis & Market Implications",
                outline=[
                    "Point 1: Macro perspective on why {0} is accelerating (+{1}% in 24h)".format(trend.title, trend.velocity),
                    "Point 2: Why legacy solutions are unprepared for this shift",
                    "Point 3: 3 strategic decisions leaders must make in the next 30 days",
                    "Point 4: Practical framework for implementation without bloating overhead",
                    "Point 5: Summary takeaway and forward outlook"
                ],
                call_to_action="How is your team responding to this shift? I'd love to hear your perspective in the comments."
            )
        else:  # Blog / Newsletter
            return PlatformContentItem(
                platform="Blog",
                title=f"The Complete Guide to {trend.title}: Catalysts, Analysis, and Playbook",
                hook=f"When {trend.title} started surging across {trend.platform}, most observers wrote it off. Here is why they were wrong.",
                angle="Comprehensive Educational Guide & Implementation Playbook",
                outline=[
                    "Introduction: The Surge of {0} (+{1}% Velocity)".format(trend.title, trend.velocity),
                    "Section 1: The Core Technological and Market Drivers",
                    "Section 2: Real-World Case Studies and Early Adopters",
                    "Section 3: Step-by-Step Creator Implementation Checklist",
                    "Section 4: Risks, Saturation Scenarios, and What Comes Next",
                    "Conclusion: Your 48-Hour Action Plan"
                ],
                call_to_action="Join 10,000+ creators getting our weekly trend intelligence breakdown by subscribing to the newsletter."
            )

    # ==========================================================================
    # Legacy Compatibility Adapters (for existing React frontend)
    # ==========================================================================

    async def analyze_trend_legacy(self, trend: TrendItem) -> AnalysisResponse:
        """Adapter matching the legacy AnalysisResponse schema expected by React OpportunityModal."""
        result = await self.analyze_trend(trend)
        longevity = (
            "Structural Shift (months)" if ("Agent" in trend.title or "Model" in trend.title or trend.velocity > 250)
            else ("Sustained Trend (weeks)" if trend.velocity > 120 else "Flash in the Pan (24-48h)")
        )
        saturation = (
            "Early Wave (Best)" if trend.velocity > 150
            else ("Peak Attention (Competitive)" if trend.velocity > 90 else "Over-Saturated")
        )

        return AnalysisResponse(
            trend_id=trend.id,
            topic=trend.title,
            analysis=TrendAnalysis(
                why_trending=result.interpretations.growth_catalysts,
                target_audience=result.interpretations.intended_audience,
                longevity_outlook=longevity,
                saturation_level=saturation,
                key_takeaway=result.interpretations.practical_recommended_action
            ),
            opportunity_score=result.opportunity_score,
            generated_by=result.provider,
            observed_facts=result.observed_facts,
            interpretations=result.interpretations,
            is_fallback=result.is_fallback,
            fallback_reason=result.fallback_reason,
            cached=result.cached
        )

    async def generate_content_ideas_legacy(
        self,
        trend: TrendItem,
        req: ContentIdeaRequest
    ) -> ContentIdeasResponse:
        """Adapter matching the legacy ContentIdeasResponse expected by React ContentIdeaGenerator."""
        c_req = ContentGenerateRequest(
            trend_id=trend.id,
            target_audience=req.target_audience,
            tone=req.tone,
            platforms=["Shorts/TikTok", "Twitter/X Thread", "LinkedIn Carousel", "Newsletter"]
        )
        result = await self.generate_content(trend, c_req)
        
        legacy_ideas: List[ContentIdea] = []
        for item in result.content_by_platform:
            legacy_ideas.append(ContentIdea(
                platform=item.platform,
                title=item.title,
                hook=item.hook,
                angle=item.angle,
                outline=item.outline,
                call_to_action=item.call_to_action,
                estimated_viral_factor="Very High" if trend.velocity > 150 else "High"
            ))

        return ContentIdeasResponse(
            trend_id=trend.id,
            topic=trend.title,
            ideas=legacy_ideas,
            generated_by=result.provider,
            observed_context=result.observed_context,
            is_fallback=result.is_fallback,
            cached=result.cached
        )

    async def generate_content_ideas(
        self,
        trend: TrendItem,
        req: ContentIdeaRequest
    ) -> ContentIdeasResponse:
        """Alias for generate_content_ideas_legacy for backwards compatibility."""
        return await self.generate_content_ideas_legacy(trend, req)


# Singleton instance
_gemini_service_instance: Optional[GeminiTrendAIService] = None

def get_gemini_service() -> GeminiTrendAIService:
    global _gemini_service_instance
    if _gemini_service_instance is None:
        _gemini_service_instance = GeminiTrendAIService()
    return _gemini_service_instance
