from __future__ import annotations

import logging
import uuid
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any

import httpx

from config import settings
from app.models.schemas import (
    SavedTrendCreate,
    SavedTrendItem,
    UserPreferencesItem,
    UserPreferencesUpdate,
    TrendHistoryItem,
    UserAlertItem,
    UserAlertCreate
)

logger = logging.getLogger("trendsetter-ai.storage")


class DuplicateTrendError(Exception):
    """Raised when attempting to save a trend already saved by the user."""
    pass


class StorageError(Exception):
    """Base exception for storage errors."""
    pass


# ==============================================================================
# Abstract Storage Repository Interface
# ==============================================================================

class BaseStorageRepository(ABC):
    """
    Abstract contract for TrendSetter AI persistence.
    Decouples business logic from the specific database backend (Supabase vs local demo).
    """

    backend_name: str = "base"

    # --- Saved Trends ---
    @abstractmethod
    async def save_trend(self, user_id: str, trend: SavedTrendCreate) -> SavedTrendItem:
        """Save a trend for a user. Prevents duplicate saves."""
        pass

    @abstractmethod
    async def list_saved_trends(self, user_id: str) -> List[SavedTrendItem]:
        """List all trends saved by a specific user."""
        pass

    @abstractmethod
    async def remove_saved_trend(self, user_id: str, trend_id: str) -> bool:
        """Remove a saved trend. Returns True if removed, False if not found."""
        pass

    @abstractmethod
    async def is_trend_saved(self, user_id: str, trend_id: str) -> bool:
        """Check whether a trend is already saved by the user."""
        pass

    # --- User Preferences ---
    @abstractmethod
    async def get_user_preferences(self, user_id: str) -> Optional[UserPreferencesItem]:
        """Retrieve user preferences (niche, audience, preferred platform)."""
        pass

    @abstractmethod
    async def save_user_preferences(self, user_id: str, prefs: UserPreferencesUpdate) -> UserPreferencesItem:
        """Create or update user preferences."""
        pass

    # --- Trend History ---
    @abstractmethod
    async def record_trend_history(
        self,
        trend_id: str,
        velocity: int,
        volume: Optional[str] = None,
        sentiment: Optional[str] = None,
        raw_score: Optional[int] = None,
        topic: Optional[str] = None,
        platform: Optional[str] = None
    ) -> TrendHistoryItem:
        """Record an observation snapshot of trend momentum."""
        pass

    @abstractmethod
    async def list_trend_history(self, trend_id: str, limit: int = 20) -> List[TrendHistoryItem]:
        """Retrieve telemetry observation history for a trend."""
        pass

    # --- User Alerts ---
    @abstractmethod
    async def create_user_alert(self, user_id: str, alert: UserAlertCreate) -> UserAlertItem:
        """Create a new velocity alert for a keyword or topic."""
        pass

    @abstractmethod
    async def list_user_alerts(self, user_id: str) -> List[UserAlertItem]:
        """List active alerts for a user."""
        pass

    @abstractmethod
    async def delete_user_alert(self, user_id: str, alert_id: str) -> bool:
        """Delete an alert."""
        pass


# ==============================================================================
# Local Demo Storage Repository (In-Memory / Zero-Dependency Fallback)
# ==============================================================================

class LocalDemoStorageRepository(BaseStorageRepository):
    """
    High-fidelity in-memory storage engine.
    Ensures 100% functionality when Supabase credentials are not configured,
    during offline hackathons, or during remote database outages.
    """

    backend_name = "local-demo"

    def __init__(self):
        # (user_id, trend_id) -> SavedTrendItem
        self._saved_trends: Dict[tuple[str, str], SavedTrendItem] = {}
        # user_id -> UserPreferencesItem
        self._preferences: Dict[str, UserPreferencesItem] = {}
        # trend_id -> List[TrendHistoryItem]
        self._history: Dict[str, List[TrendHistoryItem]] = {}
        # alert_id -> UserAlertItem
        self._alerts: Dict[str, UserAlertItem] = {}

        self._seed_demo_data()

    def _seed_demo_data(self):
        """Seed initial realistic data for demo-user so the app feels alive out of the box."""
        now = datetime.now(timezone.utc).isoformat()
        demo_user = settings.DEFAULT_USER_ID

        # Default preferences
        self._preferences[demo_user] = UserPreferencesItem(
            id=str(uuid.uuid4()),
            user_id=demo_user,
            niche="Tech & AI Engineering",
            audience="Software Engineers & Tech Leads",
            preferred_platform="LinkedIn",
            created_at=now,
            updated_at=now
        )

        # Preloaded saved trend
        initial_trend = SavedTrendItem(
            id=str(uuid.uuid4()),
            user_id=demo_user,
            trend_id="trend-01",
            title="Local Small Language Models (SLMs) on Mobile Devices",
            category="Tech & AI",
            platform="Hacker News",
            velocity=340,
            volume="94.2K mentions",
            sentiment="positive",
            source_url="https://news.ycombinator.com",
            notes="High priority viral window for edge AI tutorials.",
            created_at=now,
            updated_at=now
        )
        self._saved_trends[(demo_user, "trend-01")] = initial_trend

    async def save_trend(self, user_id: str, trend: SavedTrendCreate) -> SavedTrendItem:
        key = (user_id, trend.trend_id)
        if key in self._saved_trends:
            raise DuplicateTrendError(f"Trend '{trend.trend_id}' is already saved by user '{user_id}'.")

        now = datetime.now(timezone.utc).isoformat()
        item = SavedTrendItem(
            id=str(uuid.uuid4()),
            user_id=user_id,
            trend_id=trend.trend_id,
            title=trend.title,
            category=trend.category,
            platform=trend.platform,
            velocity=trend.velocity,
            volume=trend.volume,
            sentiment=trend.sentiment,
            source_url=trend.source_url,
            notes=trend.notes,
            created_at=now,
            updated_at=now
        )
        self._saved_trends[key] = item
        return item

    async def list_saved_trends(self, user_id: str) -> List[SavedTrendItem]:
        user_items = [
            item for (u, _), item in self._saved_trends.items()
            if u == user_id
        ]
        # Sort newest first
        user_items.sort(key=lambda x: x.created_at, reverse=True)
        return user_items

    async def remove_saved_trend(self, user_id: str, trend_id: str) -> bool:
        key = (user_id, trend_id)
        if key in self._saved_trends:
            del self._saved_trends[key]
            return True
        return False

    async def is_trend_saved(self, user_id: str, trend_id: str) -> bool:
        return (user_id, trend_id) in self._saved_trends

    async def get_user_preferences(self, user_id: str) -> Optional[UserPreferencesItem]:
        return self._preferences.get(user_id)

    async def save_user_preferences(self, user_id: str, prefs: UserPreferencesUpdate) -> UserPreferencesItem:
        now = datetime.now(timezone.utc).isoformat()
        existing = self._preferences.get(user_id)
        if existing:
            updated = existing.model_copy(update={
                "niche": prefs.niche if prefs.niche is not None else existing.niche,
                "audience": prefs.audience if prefs.audience is not None else existing.audience,
                "preferred_platform": prefs.preferred_platform if prefs.preferred_platform is not None else existing.preferred_platform,
                "updated_at": now
            })
            self._preferences[user_id] = updated
            return updated

        new_pref = UserPreferencesItem(
            id=str(uuid.uuid4()),
            user_id=user_id,
            niche=prefs.niche or "Tech & Startups",
            audience=prefs.audience or "Creators & Builders",
            preferred_platform=prefs.preferred_platform or "YouTube",
            created_at=now,
            updated_at=now
        )
        self._preferences[user_id] = new_pref
        return new_pref

    async def record_trend_history(
        self,
        trend_id: str,
        velocity: int,
        volume: Optional[str] = None,
        sentiment: Optional[str] = None,
        raw_score: Optional[int] = None,
        topic: Optional[str] = None,
        platform: Optional[str] = None
    ) -> TrendHistoryItem:
        now = datetime.now(timezone.utc).isoformat()
        item = TrendHistoryItem(
            id=str(uuid.uuid4()),
            trend_id=trend_id,
            topic=topic,
            platform=platform,
            velocity=velocity,
            volume=volume,
            sentiment=sentiment,
            raw_score=raw_score,
            observed_at=now,
            created_at=now
        )
        if trend_id not in self._history:
            self._history[trend_id] = []
        self._history[trend_id].append(item)
        return item

    async def list_trend_history(self, trend_id: str, limit: int = 20) -> List[TrendHistoryItem]:
        records = self._history.get(trend_id, [])
        return sorted(records, key=lambda x: x.observed_at, reverse=True)[:limit]

    async def create_user_alert(self, user_id: str, alert: UserAlertCreate) -> UserAlertItem:
        now = datetime.now(timezone.utc).isoformat()
        item = UserAlertItem(
            id=str(uuid.uuid4()),
            user_id=user_id,
            topic_or_keyword=alert.topic_or_keyword,
            category=alert.category,
            min_velocity=alert.min_velocity,
            is_active=True,
            last_triggered_at=None,
            created_at=now,
            updated_at=now
        )
        self._alerts[item.id] = item
        return item

    async def list_user_alerts(self, user_id: str) -> List[UserAlertItem]:
        user_alerts = [a for a in self._alerts.values() if a.user_id == user_id]
        return sorted(user_alerts, key=lambda x: x.created_at, reverse=True)

    async def delete_user_alert(self, user_id: str, alert_id: str) -> bool:
        if alert_id in self._alerts and self._alerts[alert_id].user_id == user_id:
            del self._alerts[alert_id]
            return True
        return False


# ==============================================================================
# Supabase PostgreSQL Storage Repository (REST / PostgREST API)
# ==============================================================================

class SupabaseStorageRepository(BaseStorageRepository):
    """
    Production storage repository connecting to Supabase via its PostgREST API.
    Uses environment variables for credentials and enforces Row Level Security.
    
    Includes an automatic Outage Circuit Breaker:
    If Supabase is unreachable or encounters HTTP 5xx errors, it transparently
    falls back to an internal LocalDemoStorageRepository so the application never breaks.
    """

    backend_name = "supabase"

    def __init__(
        self,
        supabase_url: Optional[str] = None,
        supabase_key: Optional[str] = None,
        timeout_seconds: Optional[int] = None
    ):
        self.url = (supabase_url or settings.SUPABASE_URL).rstrip("/")
        self.key = supabase_key or settings.SUPABASE_KEY
        self.timeout = timeout_seconds or settings.STORAGE_TIMEOUT_SECONDS
        self._fallback_repo = LocalDemoStorageRepository()

    def _get_headers(self) -> Dict[str, str]:
        return {
            "apikey": self.key,
            "Authorization": f"Bearer {self.key}",
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        }

    async def save_trend(self, user_id: str, trend: SavedTrendCreate) -> SavedTrendItem:
        now = datetime.now(timezone.utc).isoformat()
        payload = {
            "id": str(uuid.uuid4()),
            "user_id": user_id,
            "trend_id": trend.trend_id,
            "title": trend.title,
            "category": trend.category,
            "platform": trend.platform,
            "velocity": trend.velocity,
            "volume": trend.volume,
            "sentiment": trend.sentiment,
            "source_url": trend.source_url,
            "notes": trend.notes,
            "created_at": now,
            "updated_at": now
        }

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                res = await client.post(
                    f"{self.url}/rest/v1/saved_trends",
                    headers=self._get_headers(),
                    json=payload
                )

                if res.status_code == 409 or (res.status_code == 400 and "duplicate key" in res.text.lower()):
                    raise DuplicateTrendError(f"Trend '{trend.trend_id}' is already saved by user '{user_id}'.")

                res.raise_for_status()
                data = res.json()
                record = data[0] if isinstance(data, list) and data else payload
                return SavedTrendItem(**record)
        except DuplicateTrendError:
            raise
        except Exception as exc:
            logger.warning(
                "Supabase save_trend failed (%s); using resilient local demo storage.", exc
            )
            return await self._fallback_repo.save_trend(user_id, trend)

    async def list_saved_trends(self, user_id: str) -> List[SavedTrendItem]:
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                res = await client.get(
                    f"{self.url}/rest/v1/saved_trends?user_id=eq.{user_id}&order=created_at.desc",
                    headers=self._get_headers()
                )
                res.raise_for_status()
                rows = res.json()
                return [SavedTrendItem(**row) for row in rows]
        except Exception as exc:
            logger.warning(
                "Supabase list_saved_trends failed (%s); serving from local demo storage.", exc
            )
            return await self._fallback_repo.list_saved_trends(user_id)

    async def remove_saved_trend(self, user_id: str, trend_id: str) -> bool:
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                res = await client.delete(
                    f"{self.url}/rest/v1/saved_trends?user_id=eq.{user_id}&trend_id=eq.{trend_id}",
                    headers=self._get_headers()
                )
                res.raise_for_status()
                rows = res.json()
                if isinstance(rows, list) and len(rows) > 0:
                    return True
                # If PostgREST didn't return representation, 204 or 200 without rows means processed
                return res.status_code in (200, 204)
        except Exception as exc:
            logger.warning(
                "Supabase remove_saved_trend failed (%s); falling back to local demo storage.", exc
            )
            return await self._fallback_repo.remove_saved_trend(user_id, trend_id)

    async def is_trend_saved(self, user_id: str, trend_id: str) -> bool:
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                res = await client.get(
                    f"{self.url}/rest/v1/saved_trends?user_id=eq.{user_id}&trend_id=eq.{trend_id}&select=id",
                    headers=self._get_headers()
                )
                res.raise_for_status()
                rows = res.json()
                return bool(rows and len(rows) > 0)
        except Exception as exc:
            logger.warning(
                "Supabase is_trend_saved failed (%s); falling back to local demo storage.", exc
            )
            return await self._fallback_repo.is_trend_saved(user_id, trend_id)

    async def get_user_preferences(self, user_id: str) -> Optional[UserPreferencesItem]:
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                res = await client.get(
                    f"{self.url}/rest/v1/user_preferences?user_id=eq.{user_id}&limit=1",
                    headers=self._get_headers()
                )
                res.raise_for_status()
                rows = res.json()
                if rows:
                    return UserPreferencesItem(**rows[0])
                return None
        except Exception as exc:
            logger.warning(
                "Supabase get_user_preferences failed (%s); falling back to local demo storage.", exc
            )
            return await self._fallback_repo.get_user_preferences(user_id)

    async def save_user_preferences(self, user_id: str, prefs: UserPreferencesUpdate) -> UserPreferencesItem:
        now = datetime.now(timezone.utc).isoformat()
        payload = {
            "user_id": user_id,
            "niche": prefs.niche,
            "audience": prefs.audience,
            "preferred_platform": prefs.preferred_platform,
            "updated_at": now
        }
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                # Upsert into user_preferences on conflict user_id
                headers = self._get_headers()
                headers["Prefer"] = "resolution=merge-duplicates,return=representation"
                res = await client.post(
                    f"{self.url}/rest/v1/user_preferences",
                    headers=headers,
                    json=payload
                )
                res.raise_for_status()
                rows = res.json()
                record = rows[0] if rows else payload
                return UserPreferencesItem(**record)
        except Exception as exc:
            logger.warning(
                "Supabase save_user_preferences failed (%s); falling back to local demo storage.", exc
            )
            return await self._fallback_repo.save_user_preferences(user_id, prefs)

    async def record_trend_history(
        self,
        trend_id: str,
        velocity: int,
        volume: Optional[str] = None,
        sentiment: Optional[str] = None,
        raw_score: Optional[int] = None,
        topic: Optional[str] = None,
        platform: Optional[str] = None
    ) -> TrendHistoryItem:
        now = datetime.now(timezone.utc).isoformat()
        payload = {
            "id": str(uuid.uuid4()),
            "trend_id": trend_id,
            "topic": topic,
            "platform": platform,
            "velocity": velocity,
            "volume": volume,
            "sentiment": sentiment,
            "raw_score": raw_score,
            "observed_at": now,
            "created_at": now
        }
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                res = await client.post(
                    f"{self.url}/rest/v1/trend_history",
                    headers=self._get_headers(),
                    json=payload
                )
                res.raise_for_status()
                rows = res.json()
                record = rows[0] if rows else payload
                return TrendHistoryItem(**record)
        except Exception as exc:
            logger.warning(
                "Supabase record_trend_history failed (%s); using local demo storage.", exc
            )
            return await self._fallback_repo.record_trend_history(
                trend_id=trend_id,
                velocity=velocity,
                volume=volume,
                sentiment=sentiment,
                raw_score=raw_score,
                topic=topic,
                platform=platform
            )

    async def list_trend_history(self, trend_id: str, limit: int = 20) -> List[TrendHistoryItem]:
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                res = await client.get(
                    f"{self.url}/rest/v1/trend_history?trend_id=eq.{trend_id}&order=observed_at.desc&limit={limit}",
                    headers=self._get_headers()
                )
                res.raise_for_status()
                rows = res.json()
                return [TrendHistoryItem(**row) for row in rows]
        except Exception as exc:
            logger.warning(
                "Supabase list_trend_history failed (%s); using local demo storage.", exc
            )
            return await self._fallback_repo.list_trend_history(trend_id, limit)

    async def create_user_alert(self, user_id: str, alert: UserAlertCreate) -> UserAlertItem:
        now = datetime.now(timezone.utc).isoformat()
        payload = {
            "id": str(uuid.uuid4()),
            "user_id": user_id,
            "topic_or_keyword": alert.topic_or_keyword,
            "category": alert.category,
            "min_velocity": alert.min_velocity,
            "is_active": True,
            "created_at": now,
            "updated_at": now
        }
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                res = await client.post(
                    f"{self.url}/rest/v1/user_alerts",
                    headers=self._get_headers(),
                    json=payload
                )
                res.raise_for_status()
                rows = res.json()
                record = rows[0] if rows else payload
                return UserAlertItem(**record)
        except Exception as exc:
            logger.warning(
                "Supabase create_user_alert failed (%s); using local demo storage.", exc
            )
            return await self._fallback_repo.create_user_alert(user_id, alert)

    async def list_user_alerts(self, user_id: str) -> List[UserAlertItem]:
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                res = await client.get(
                    f"{self.url}/rest/v1/user_alerts?user_id=eq.{user_id}&order=created_at.desc",
                    headers=self._get_headers()
                )
                res.raise_for_status()
                rows = res.json()
                return [UserAlertItem(**row) for row in rows]
        except Exception as exc:
            logger.warning(
                "Supabase list_user_alerts failed (%s); using local demo storage.", exc
            )
            return await self._fallback_repo.list_user_alerts(user_id)

    async def delete_user_alert(self, user_id: str, alert_id: str) -> bool:
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                res = await client.delete(
                    f"{self.url}/rest/v1/user_alerts?user_id=eq.{user_id}&id=eq.{alert_id}",
                    headers=self._get_headers()
                )
                res.raise_for_status()
                return res.status_code in (200, 204)
        except Exception as exc:
            logger.warning(
                "Supabase delete_user_alert failed (%s); using local demo storage.", exc
            )
            return await self._fallback_repo.delete_user_alert(user_id, alert_id)


# ==============================================================================
# Repository Factory Function
# ==============================================================================

_storage_repository_instance: Optional[BaseStorageRepository] = None


def get_storage_repository() -> BaseStorageRepository:
    """
    Singleton factory returning the appropriate storage repository.
    Selects Supabase if configured, otherwise returns local demo storage.
    """
    global _storage_repository_instance
    if _storage_repository_instance is None:
        mode = settings.STORAGE_MODE.lower()
        if mode == "local-demo":
            logger.info("STORAGE_MODE explicitly set to 'local-demo'. Using LocalDemoStorageRepository.")
            _storage_repository_instance = LocalDemoStorageRepository()
        elif settings.is_supabase_configured:
            logger.info("Supabase credentials detected. Initializing SupabaseStorageRepository.")
            _storage_repository_instance = SupabaseStorageRepository()
        else:
            logger.info("Supabase not configured. Initializing LocalDemoStorageRepository.")
            _storage_repository_instance = LocalDemoStorageRepository()

    return _storage_repository_instance
