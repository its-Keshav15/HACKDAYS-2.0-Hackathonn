"""
Backward-compatibility adapter for Gemini Analyzer.
Delegates to the new GeminiTrendAIService.
"""
from typing import Optional
from app.models.schemas import (
    TrendItem,
    AnalysisResponse,
    ContentIdeasResponse,
    ContentIdeaRequest
)
from app.services.gemini_service import get_gemini_service, GeminiTrendAIService

class GeminiAnalyzerService:
    def __init__(self):
        self._service = get_gemini_service()

    async def analyze_trend(self, trend: TrendItem) -> AnalysisResponse:
        return await self._service.analyze_trend_legacy(trend)

    async def generate_content_ideas(
        self,
        trend: TrendItem,
        req: ContentIdeaRequest
    ) -> ContentIdeasResponse:
        return await self._service.generate_content_ideas_legacy(trend, req)

# Global singleton
_analyzer_instance: Optional[GeminiAnalyzerService] = None

def get_analyzer_service() -> GeminiAnalyzerService:
    global _analyzer_instance
    if _analyzer_instance is None:
        _analyzer_instance = GeminiAnalyzerService()
    return _analyzer_instance

# Re-export get_gemini_service for existing modules
__all__ = ["GeminiAnalyzerService", "get_analyzer_service", "get_gemini_service"]
