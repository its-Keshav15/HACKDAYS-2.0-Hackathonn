from typing import List, Optional, Dict
from abc import ABC, abstractmethod
import datetime
from app.models.schemas import TrendItem

class TrendDataSource(ABC):
    """Abstract interface for external trend intelligence sources."""
    @abstractmethod
    def fetch_trends(self) -> List[TrendItem]:
        pass

class MockTrendRadarSource(TrendDataSource):
    """
    Default high-fidelity mock data source for hackathon MVP.
    Provides realistic, multi-platform trending topics with rich metadata.
    """
    def __init__(self):
        self._mock_data: List[TrendItem] = [
            TrendItem(
                id="trend-01",
                title="Local Small Language Models (SLMs) on Mobile Devices",
                description="Developers and tech creators are showcasing high-speed, offline LLM inference directly on smartphones and edge hardware without cloud subscription costs.",
                category="Tech & AI",
                platform="Hacker News",
                velocity=340,
                volume="94.2K mentions",
                sentiment="positive",
                tags=["AI", "OnDeviceAI", "OpenSource", "MobileDev"],
                source_url="https://news.ycombinator.com",
                first_detected="3 hours ago",
                raw_score=94
            ),
            TrendItem(
                id="trend-02",
                title="Micro-SaaS 'One-Person Company' Stacks",
                description="Solopreneurs sharing automated growth playbooks generating $10k MRR using no-code automations, AI agents, and lean marketing stacks.",
                category="Business & Startups",
                platform="X",
                velocity=215,
                volume="168.5K mentions",
                sentiment="positive",
                tags=["Solopreneur", "SaaS", "IndieHacker", "PassiveIncome"],
                source_url="https://x.com",
                first_detected="5 hours ago",
                raw_score=89
            ),
            TrendItem(
                id="trend-03",
                title="Spatial Audio & Short-form Immersion Editing",
                description="Viral TikTok & Reels video editors adopting binaural spatial audio layers to boost video watch time and 100% completion rates.",
                category="Creator Economy",
                platform="TikTok",
                velocity=190,
                volume="240.1K videos",
                sentiment="positive",
                tags=["VideoEditing", "TikTokGrowth", "AudioProduction", "ViralHooks"],
                source_url="https://tiktok.com",
                first_detected="8 hours ago",
                raw_score=87
            ),
            TrendItem(
                id="trend-04",
                title="AI Agentic Workflows replacing Traditional Zapier Zaps",
                description="The transition from rigid trigger-action automations to autonomous reasoning agents using function calling and self-healing loops.",
                category="Tech & AI",
                platform="Reddit",
                velocity=165,
                volume="42.8K upvotes",
                sentiment="neutral",
                tags=["Automation", "AIAgents", "Productivity", "Python"],
                source_url="https://reddit.com/r/MachineLearning",
                first_detected="11 hours ago",
                raw_score=82
            ),
            TrendItem(
                id="trend-05",
                title="Cottagecore Tech & Minimalist E-Ink Daily Drivers",
                description="Lifestyle creators ditching high-refresh OLED phones for distraction-free E-ink tablets and minimalist mechanical keyboards.",
                category="Pop Culture",
                platform="Google Trends",
                velocity=125,
                volume="+450% breakout search",
                sentiment="positive",
                tags=["DigitalDetox", "Minimalism", "EInk", "ProductivityAesthetic"],
                source_url="https://trends.google.com",
                first_detected="1 day ago",
                raw_score=78
            ),
            TrendItem(
                id="trend-06",
                title="Synthetic UGC Advertising Fatigue",
                description="Debate on Reddit and Marketing Twitter concerning audience blindness to obvious AI-generated avatar commercials and cloned voices.",
                category="Creator Economy",
                platform="Reddit",
                velocity=110,
                volume="58.3K comments",
                sentiment="controversial",
                tags=["UGC", "MarketingTrends", "Authenticity", "AIAdvertising"],
                source_url="https://reddit.com/r/marketing",
                first_detected="1 day ago",
                raw_score=75
            ),
            TrendItem(
                id="trend-07",
                title="Zero-Knowledge Data Privacy in FinTech Apps",
                description="Mass adoption of ZK-proofs in consumer banking and decentralized payroll to verify credit and identity without exposing raw PII.",
                category="Business & Startups",
                platform="X",
                velocity=95,
                volume="31.2K tweets",
                sentiment="positive",
                tags=["Fintech", "Privacy", "ZKProofs", "Security"],
                source_url="https://x.com",
                first_detected="2 days ago",
                raw_score=71
            ),
            TrendItem(
                id="trend-08",
                title="Co-op Cozy Gaming Boom on Steam Deck",
                description="Indie low-stress multiplayer games surging past AAA competitive shooters as casual streamers build community game nights.",
                category="Gaming & Pop Culture",
                platform="TikTok",
                velocity=85,
                volume="112.4K shares",
                sentiment="positive",
                tags=["Gaming", "CozyGames", "SteamDeck", "IndieDev"],
                source_url="https://tiktok.com",
                first_detected="2 days ago",
                raw_score=68
            )
        ]

    def fetch_trends(self) -> List[TrendItem]:
        return self._mock_data

class LiveTrendRadarSource(TrendDataSource):
    """
    Production adapter for connecting to external live trend APIs (e.g. TrendRadar, Google Trends RSS, Reddit API).
    Falls back cleanly to mock data if unconfigured.
    """
    def __init__(self, api_url: Optional[str] = None):
        self.api_url = api_url
        self.fallback = MockTrendRadarSource()

    def fetch_trends(self) -> List[TrendItem]:
        if not self.api_url:
            return self.fallback.fetch_trends()
        # Live external fetch implementation hook
        try:
            # External HTTP request logic goes here
            return self.fallback.fetch_trends()
        except Exception:
            return self.fallback.fetch_trends()

class TrendRadarService:
    def __init__(self, mode: str = "mock"):
        if mode == "live":
            self.source: TrendDataSource = LiveTrendRadarSource()
        else:
            self.source: TrendDataSource = MockTrendRadarSource()

    def get_all_trends(
        self,
        category: Optional[str] = None,
        platform: Optional[str] = None,
        min_velocity: Optional[int] = None,
        search: Optional[str] = None
    ) -> List[TrendItem]:
        trends = self.source.fetch_trends()
        
        if category and category.lower() != "all":
            trends = [t for t in trends if t.category.lower() == category.lower()]
            
        if platform and platform.lower() != "all":
            trends = [t for t in trends if t.platform.lower() == platform.lower()]
            
        if min_velocity is not None:
            trends = [t for t in trends if t.velocity >= min_velocity]
            
        if search:
            query = search.lower().strip()
            trends = [
                t for t in trends
                if query in t.title.lower()
                or query in t.description.lower()
                or any(query in tag.lower() for tag in t.tags)
            ]
            
        # Sort primarily by velocity descending
        return sorted(trends, key=lambda t: t.velocity, reverse=True)

    def get_trend_by_id(self, trend_id: str) -> Optional[TrendItem]:
        for trend in self.source.fetch_trends():
            if trend.id == trend_id:
                return trend
        return None

    def get_categories(self) -> List[str]:
        trends = self.source.fetch_trends()
        return sorted(list(set(t.category for t in trends)))

    def get_platforms(self) -> List[str]:
        trends = self.source.fetch_trends()
        return sorted(list(set(t.platform for t in trends)))

# Singleton instance
_trend_service_instance: Optional[TrendRadarService] = None

def get_trend_radar_service(mode: str = "mock") -> TrendRadarService:
    global _trend_service_instance
    if _trend_service_instance is None:
        _trend_service_instance = TrendRadarService(mode=mode)
    return _trend_service_instance
