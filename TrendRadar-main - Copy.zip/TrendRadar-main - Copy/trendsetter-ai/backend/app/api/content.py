from typing import Optional
from fastapi import APIRouter, HTTPException, Query
from config import settings
from app.models.schemas import (
    ContentGenerateRequest,
    ContentGenerationResult
)
from app.services.trend_radar import get_trend_radar_service
from app.services.gemini_service import get_gemini_service

router = APIRouter()

@router.post("/generate", response_model=ContentGenerationResult)
async def generate_content_endpoint(
    request: Optional[ContentGenerateRequest] = None,
    trend_id: Optional[str] = Query(None, description="Optional trend_id query parameter")
):
    """
    POST /api/content/generate
    Generate platform-specific content blueprints for YouTube, Instagram, LinkedIn, and Blogs.
    Includes high-converting titles, hooks, outlines, and calls to action.
    """
    req = request or ContentGenerateRequest()
    req_trend_id = req.trend_id
    trend_payload = req.trend

    if not req_trend_id and trend_id:
        req_trend_id = trend_id

    if trend_payload:
        trend = trend_payload
    elif req_trend_id:
        service = get_trend_radar_service(mode=settings.TREND_SOURCE_MODE)
        trend = service.get_trend_by_id(req_trend_id)
        if not trend:
            raise HTTPException(status_code=404, detail=f"Trend '{req_trend_id}' not found")
    else:
        raise HTTPException(
            status_code=400,
            detail="Must provide either 'trend_id' or 'trend' payload in the request body."
        )

    ai_service = get_gemini_service()
    return await ai_service.generate_content(trend, req)
