from typing import Optional, List
from fastapi import APIRouter, HTTPException, Header, status
from config import settings
from app.models.schemas import (
    SavedTrendCreate,
    SavedTrendItem,
    SavedTrendListResponse,
    UserPreferencesItem,
    UserPreferencesUpdate,
    TrendHistoryItem
)
from app.services.storage.repository import get_storage_repository, DuplicateTrendError

router = APIRouter()


def get_current_user_id(x_user_id: Optional[str] = Header(None)) -> str:
    """
    Extract user ID from X-User-ID header or fall back to default demo identity.
    Ensures the app works seamlessly without forcing a rigid fake authentication system.
    """
    if x_user_id and x_user_id.strip():
        return x_user_id.strip()
    return settings.DEFAULT_USER_ID


# ==============================================================================
# Saved Trends Endpoints (/api/saved-trends)
# ==============================================================================

@router.post("", response_model=SavedTrendItem, status_code=status.HTTP_201_CREATED)
async def save_trend(
    trend_data: SavedTrendCreate,
    x_user_id: Optional[str] = Header(None)
):
    """
    Save a trending topic to the creator's saved list.
    Enforces uniqueness: prevents saving the same trend multiple times for the same user.
    """
    user_id = get_current_user_id(x_user_id)
    repo = get_storage_repository()
    try:
        saved_item = await repo.save_trend(user_id=user_id, trend=trend_data)
        return saved_item
    except DuplicateTrendError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc)
        )


@router.get("", response_model=SavedTrendListResponse)
async def list_saved_trends(x_user_id: Optional[str] = Header(None)):
    """
    Retrieve all trends saved by the creator.
    """
    user_id = get_current_user_id(x_user_id)
    repo = get_storage_repository()
    items = await repo.list_saved_trends(user_id=user_id)
    return SavedTrendListResponse(
        total=len(items),
        items=items,
        storage_backend=repo.backend_name
    )


@router.delete("/{trend_id}")
async def remove_saved_trend(
    trend_id: str,
    x_user_id: Optional[str] = Header(None)
):
    """
    Remove a saved trend from the creator's list.
    """
    user_id = get_current_user_id(x_user_id)
    repo = get_storage_repository()
    success = await repo.remove_saved_trend(user_id=user_id, trend_id=trend_id)
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Saved trend '{trend_id}' not found for user."
        )
    return {"deleted": True, "trend_id": trend_id, "user_id": user_id}


@router.get("/{trend_id}/status")
async def check_saved_status(
    trend_id: str,
    x_user_id: Optional[str] = Header(None)
):
    """
    Check if a specific trend is already saved by the creator.
    """
    user_id = get_current_user_id(x_user_id)
    repo = get_storage_repository()
    is_saved = await repo.is_trend_saved(user_id=user_id, trend_id=trend_id)
    return {"trend_id": trend_id, "is_saved": is_saved, "user_id": user_id}


# ==============================================================================
# User Preferences Endpoints
# ==============================================================================

@router.get("/user/preferences", response_model=Optional[UserPreferencesItem])
async def get_preferences(x_user_id: Optional[str] = Header(None)):
    """
    Retrieve creator preferences (niche, audience, preferred platform).
    """
    user_id = get_current_user_id(x_user_id)
    repo = get_storage_repository()
    return await repo.get_user_preferences(user_id=user_id)


@router.put("/user/preferences", response_model=UserPreferencesItem)
async def update_preferences(
    prefs: UserPreferencesUpdate,
    x_user_id: Optional[str] = Header(None)
):
    """
    Update or initialize creator preferences.
    """
    user_id = get_current_user_id(x_user_id)
    repo = get_storage_repository()
    return await repo.save_user_preferences(user_id=user_id, prefs=prefs)
