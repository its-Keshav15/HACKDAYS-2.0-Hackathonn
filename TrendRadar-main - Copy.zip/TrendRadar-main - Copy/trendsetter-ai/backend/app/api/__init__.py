from fastapi import APIRouter
from .trends import router as trends_router
from .analysis import router as analysis_router
from .ideas import router as ideas_router
from .content import router as content_router
from .saved_trends import router as saved_trends_router

api_router = APIRouter()
api_router.include_router(trends_router, prefix="/trends", tags=["Trends"])
api_router.include_router(analysis_router, prefix="/trends", tags=["Analysis & Opportunity Scoring"])
api_router.include_router(ideas_router, prefix="/trends", tags=["Content Ideas"])
api_router.include_router(content_router, prefix="/content", tags=["Content Generation"])
api_router.include_router(saved_trends_router, prefix="/saved-trends", tags=["Saved Trends & Creator Library"])

__all__ = ["api_router"]
