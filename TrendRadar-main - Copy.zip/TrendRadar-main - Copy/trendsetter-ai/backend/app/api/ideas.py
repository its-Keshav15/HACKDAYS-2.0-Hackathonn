from fastapi import APIRouter, HTTPException
from config import settings
from app.models.schemas import ContentIdeasResponse, ContentIdeaRequest
from app.services.trend_radar import get_trend_radar_service
from app.services.gemini_analyzer import get_gemini_service

router = APIRouter()

@router.post("/{trend_id}/ideas", response_model=ContentIdeasResponse)
async def generate_ideas_post(trend_id: str, request: ContentIdeaRequest):
    """
    Generate tailored viral content ideas, hooks, outlines, and CTAs using Gemini API.
    """
    trend_service = get_trend_radar_service(mode=settings.TREND_SOURCE_MODE)
    trend = trend_service.get_trend_by_id(trend_id)
    if not trend:
        raise HTTPException(status_code=404, detail=f"Trend '{trend_id}' not found")

    gemini_service = get_gemini_service()
    ideas_res = await gemini_service.generate_content_ideas(trend, request)
    return ideas_res

@router.get("/{trend_id}/ideas", response_model=ContentIdeasResponse)
async def generate_ideas_get(trend_id: str):
    """
    Quick endpoint to generate default viral content ideas for a trend.
    """
    default_request = ContentIdeaRequest(
        target_audience="Creators & Growth Teams",
        tone="Punchy, actionable, and engaging"
    )
    return await generate_ideas_post(trend_id, default_request)
