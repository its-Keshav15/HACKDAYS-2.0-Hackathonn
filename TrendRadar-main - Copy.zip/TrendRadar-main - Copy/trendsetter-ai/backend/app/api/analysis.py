from fastapi import APIRouter, HTTPException
from config import settings
from app.models.schemas import AnalysisResponse, OpportunityScore
from app.services.trend_radar import get_trend_radar_service
from app.services.gemini_service import get_gemini_service
from app.services.opportunity_scorer import OpportunityScorer

router = APIRouter()

@router.post("/{trend_id}/analyze", response_model=AnalysisResponse)
@router.get("/{trend_id}/analyze", response_model=AnalysisResponse)
async def analyze_trend(trend_id: str):
    """
    Generate deep AI Trend Analysis and Opportunity Score using Gemini API.
    Falls back gracefully to the intelligent heuristic engine when GEMINI_API_KEY is not configured.
    """
    trend_service = get_trend_radar_service(mode=settings.TREND_SOURCE_MODE)
    trend = trend_service.get_trend_by_id(trend_id)
    if not trend:
        raise HTTPException(status_code=404, detail=f"Trend '{trend_id}' not found")

    gemini_service = get_gemini_service()
    analysis_res = await gemini_service.analyze_trend_legacy(trend)
    return analysis_res

@router.get("/{trend_id}/score", response_model=OpportunityScore)
def get_opportunity_score(trend_id: str):
    """
    Retrieve immediate multi-dimensional opportunity score computed for a trend.
    """
    trend_service = get_trend_radar_service(mode=settings.TREND_SOURCE_MODE)
    trend = trend_service.get_trend_by_id(trend_id)
    if not trend:
        raise HTTPException(status_code=404, detail=f"Trend '{trend_id}' not found")

    return OpportunityScorer.calculate_score(trend)
