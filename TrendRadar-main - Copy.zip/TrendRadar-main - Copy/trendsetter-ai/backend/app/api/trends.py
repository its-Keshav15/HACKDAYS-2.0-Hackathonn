from typing import Optional, List
from fastapi import APIRouter, HTTPException, Query
from config import settings
from app.models.schemas import (
    TrendItem,
    TrendListResponse,
    TrendAnalyzeRequest,
    TrendAnalysisResult
)
from app.services.trend_radar import get_trend_radar_service
from app.services.gemini_service import get_gemini_service

router = APIRouter()

@router.get("", response_model=TrendListResponse)
def list_trends(
    category: Optional[str] = Query(None, description="Filter by category (e.g. 'Tech & AI')"),
    platform: Optional[str] = Query(None, description="Filter by platform (e.g. 'TikTok', 'X')"),
    min_velocity: Optional[int] = Query(None, description="Minimum growth velocity percentage"),
    search: Optional[str] = Query(None, description="Search term for title, description, or tags")
):
    """
    Retrieve trending topics collected by TrendRadar Intelligence Service.
    Supports multi-attribute filtering and full-text keyword search.
    """
    service = get_trend_radar_service(mode=settings.TREND_SOURCE_MODE)
    trends = service.get_all_trends(
        category=category,
        platform=platform,
        min_velocity=min_velocity,
        search=search
    )
    categories = service.get_categories()
    platforms = service.get_platforms()

    return TrendListResponse(
        total=len(trends),
        categories=categories,
        platforms=platforms,
        trends=trends,
        source_mode=settings.TREND_SOURCE_MODE
    )

@router.get("/categories", response_model=List[str])
def list_categories():
    """Retrieve all available category filters."""
    service = get_trend_radar_service(mode=settings.TREND_SOURCE_MODE)
    return service.get_categories()

@router.get("/platforms", response_model=List[str])
def list_platforms():
    """Retrieve all tracked platform sources."""
    service = get_trend_radar_service(mode=settings.TREND_SOURCE_MODE)
    return service.get_platforms()

@router.post("/analyze", response_model=TrendAnalysisResult)
async def analyze_trend_endpoint(
    request: Optional[TrendAnalyzeRequest] = None,
    trend_id: Optional[str] = Query(None, description="Optional trend_id query parameter")
):
    """
    POST /api/trends/analyze
    Perform structured Gemini AI trend analysis and deterministic opportunity scoring.
    Accepts 'trend_id' (to fetch from trend radar) or inline 'trend' payload in the request body.
    """
    req_trend_id = None
    trend_payload = None
    if request:
        req_trend_id = request.trend_id
        trend_payload = request.trend
    if not req_trend_id and trend_id:
        req_trend_id = trend_id

    if trend_payload:
        trend = trend_payload
    elif req_trend_id:
        service = get_trend_radar_service(mode=settings.TREND_SOURCE_MODE)
        trend = service.get_trend_by_id(req_trend_id)
        if not trend:
            raise HTTPException(status_code=404, detail=f"Trend '{req_trend_id}' not found")
    else:
        raise HTTPException(
            status_code=400,
            detail="Must provide either 'trend_id' or 'trend' payload in the request body."
        )

    ai_service = get_gemini_service()
    return await ai_service.analyze_trend(trend)

@router.get("/{trend_id}", response_model=TrendItem)
def get_trend(trend_id: str):
    """Retrieve detailed metadata for a specific trend by ID."""
    service = get_trend_radar_service(mode=settings.TREND_SOURCE_MODE)
    trend = service.get_trend_by_id(trend_id)
    if not trend:
        raise HTTPException(status_code=404, detail=f"Trend '{trend_id}' not found")
    return trend
