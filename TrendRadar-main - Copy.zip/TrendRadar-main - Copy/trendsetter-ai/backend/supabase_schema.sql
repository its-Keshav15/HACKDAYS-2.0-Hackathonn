-- ==============================================================================
-- TrendSetter AI - Supabase / PostgreSQL Database Schema
-- Run this script in the Supabase SQL Editor (Dashboard > SQL Editor > New Query)
-- ==============================================================================

-- 1. Enable pgcrypto / uuid extensions if not already present
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 2. Helper function to automatically update `updated_at` timestamps
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;


-- ==============================================================================
-- Table 1: user_preferences
-- Stores niche, audience demographic, and primary platform preferences.
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.user_preferences (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT NOT NULL,
    niche TEXT,
    audience TEXT,
    preferred_platform TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uq_user_preferences_user UNIQUE (user_id)
);

CREATE INDEX IF NOT EXISTS idx_user_preferences_user ON public.user_preferences(user_id);

DROP TRIGGER IF EXISTS tr_user_preferences_updated_at ON public.user_preferences;
CREATE TRIGGER tr_user_preferences_updated_at
    BEFORE UPDATE ON public.user_preferences
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();


-- ==============================================================================
-- Table 2: saved_trends
-- Stores curated trends saved by creators. Prevents duplicate saves per user.
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.saved_trends (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT NOT NULL,
    trend_id TEXT NOT NULL,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    platform TEXT NOT NULL,
    velocity INT NOT NULL DEFAULT 0,
    volume TEXT,
    sentiment TEXT,
    source_url TEXT,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uq_saved_trends_user_trend UNIQUE (user_id, trend_id)
);

CREATE INDEX IF NOT EXISTS idx_saved_trends_user_created ON public.saved_trends(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_saved_trends_trend_id ON public.saved_trends(trend_id);
CREATE INDEX IF NOT EXISTS idx_saved_trends_category ON public.saved_trends(category);

DROP TRIGGER IF EXISTS tr_saved_trends_updated_at ON public.saved_trends;
CREATE TRIGGER tr_saved_trends_updated_at
    BEFORE UPDATE ON public.saved_trends
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();


-- ==============================================================================
-- Table 3: trend_history
-- Telemetry log capturing historical snapshots and observation timestamps.
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.trend_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    trend_id TEXT NOT NULL,
    topic TEXT,
    platform TEXT,
    velocity INT NOT NULL DEFAULT 0,
    volume TEXT,
    sentiment TEXT,
    raw_score INT,
    observed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_trend_history_trend_observed ON public.trend_history(trend_id, observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_trend_history_observed_at ON public.trend_history(observed_at DESC);


-- ==============================================================================
-- Table 4: generated_content_ideas
-- Stores viral blueprints, hooks, outlines, and CTAs generated for a trend.
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.generated_content_ideas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT,
    trend_id TEXT NOT NULL,
    platform TEXT NOT NULL,
    title TEXT,
    hook TEXT,
    angle TEXT,
    outline JSONB,
    call_to_action TEXT,
    provider TEXT DEFAULT 'gemini',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_content_ideas_trend_platform ON public.generated_content_ideas(trend_id, platform);
CREATE INDEX IF NOT EXISTS idx_content_ideas_user ON public.generated_content_ideas(user_id);
CREATE INDEX IF NOT EXISTS idx_content_ideas_created ON public.generated_content_ideas(created_at DESC);

DROP TRIGGER IF EXISTS tr_generated_content_ideas_updated_at ON public.generated_content_ideas;
CREATE TRIGGER tr_generated_content_ideas_updated_at
    BEFORE UPDATE ON public.generated_content_ideas
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();


-- ==============================================================================
-- Table 5: user_alerts
-- Real-time watcher configurations triggering notifications when momentum spikes.
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.user_alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT NOT NULL,
    topic_or_keyword TEXT NOT NULL,
    category TEXT,
    min_velocity INT NOT NULL DEFAULT 100,
    is_active BOOLEAN NOT NULL DEFAULT true,
    last_triggered_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_user_alerts_user_active ON public.user_alerts(user_id, is_active);

DROP TRIGGER IF EXISTS tr_user_alerts_updated_at ON public.user_alerts;
CREATE TRIGGER tr_user_alerts_updated_at
    BEFORE UPDATE ON public.user_alerts
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();


-- ==============================================================================
-- Row Level Security (RLS) Policies
-- Protects user data while supporting both Supabase Auth & Demo/Guest workflows.
-- ==============================================================================

-- 1. Enable RLS on all tables
ALTER TABLE public.user_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.saved_trends ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.generated_content_ideas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.trend_history ENABLE ROW LEVEL SECURITY;

-- 2. Policies for user_preferences
-- Authenticated users access their own record; demo users can manage 'demo-user' data.
CREATE POLICY "Allow individual user preferences access"
    ON public.user_preferences
    FOR ALL
    USING (
        (auth.uid() IS NOT NULL AND auth.uid()::text = user_id)
        OR (auth.uid() IS NULL AND user_id = 'demo-user')
        OR (current_setting('request.jwt.claim.sub', true) = user_id)
    )
    WITH CHECK (
        (auth.uid() IS NOT NULL AND auth.uid()::text = user_id)
        OR (auth.uid() IS NULL AND user_id = 'demo-user')
        OR (current_setting('request.jwt.claim.sub', true) = user_id)
    );

-- 3. Policies for saved_trends
CREATE POLICY "Allow individual user saved trends access"
    ON public.saved_trends
    FOR ALL
    USING (
        (auth.uid() IS NOT NULL AND auth.uid()::text = user_id)
        OR (auth.uid() IS NULL AND user_id = 'demo-user')
        OR (current_setting('request.jwt.claim.sub', true) = user_id)
    )
    WITH CHECK (
        (auth.uid() IS NOT NULL AND auth.uid()::text = user_id)
        OR (auth.uid() IS NULL AND user_id = 'demo-user')
        OR (current_setting('request.jwt.claim.sub', true) = user_id)
    );

-- 4. Policies for generated_content_ideas
CREATE POLICY "Allow individual user content ideas access"
    ON public.generated_content_ideas
    FOR ALL
    USING (
        user_id IS NULL
        OR (auth.uid() IS NOT NULL AND auth.uid()::text = user_id)
        OR (auth.uid() IS NULL AND user_id = 'demo-user')
    )
    WITH CHECK (
        user_id IS NULL
        OR (auth.uid() IS NOT NULL AND auth.uid()::text = user_id)
        OR (auth.uid() IS NULL AND user_id = 'demo-user')
    );

-- 5. Policies for user_alerts
CREATE POLICY "Allow individual user alerts access"
    ON public.user_alerts
    FOR ALL
    USING (
        (auth.uid() IS NOT NULL AND auth.uid()::text = user_id)
        OR (auth.uid() IS NULL AND user_id = 'demo-user')
    )
    WITH CHECK (
        (auth.uid() IS NOT NULL AND auth.uid()::text = user_id)
        OR (auth.uid() IS NULL AND user_id = 'demo-user')
    );

-- 6. Policies for trend_history (Public Read / Service Write)
CREATE POLICY "Allow public read of trend history"
    ON public.trend_history
    FOR SELECT
    USING (true);

CREATE POLICY "Allow authenticated or demo insertion of trend history"
    ON public.trend_history
    FOR INSERT
    WITH CHECK (true);
