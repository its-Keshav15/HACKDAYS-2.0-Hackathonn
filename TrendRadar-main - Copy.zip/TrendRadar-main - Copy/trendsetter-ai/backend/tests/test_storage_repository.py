import pytest
from unittest.mock import patch, MagicMock
from fastapi.testclient import TestClient
from main import app
from app.models.schemas import SavedTrendCreate, UserPreferencesUpdate
from app.services.storage.repository import (
    LocalDemoStorageRepository,
    SupabaseStorageRepository,
    DuplicateTrendError,
    get_storage_repository
)

client = TestClient(app)

@pytest.fixture
def repo():
    return LocalDemoStorageRepository()

@pytest.fixture
def sample_trend_data():
    return SavedTrendCreate(
        trend_id="trend-ai-01",
        title="Agentic Workflows in Production",
        category="Tech & AI",
        platform="Hacker News",
        velocity=250,
        volume="45K posts",
        sentiment="positive",
        source_url="https://news.ycombinator.com",
        notes="Important for creator growth newsletter."
    )


# ==============================================================================
# Unit Tests for Storage Repository
# ==============================================================================

@pytest.mark.anyio
async def test_save_and_list_saved_trend(repo, sample_trend_data):
    """Test saving a trend and listing it for a user."""
    user = "test-creator-1"
    item = await repo.save_trend(user_id=user, trend=sample_trend_data)

    assert item.id is not None
    assert item.user_id == user
    assert item.trend_id == sample_trend_data.trend_id
    assert item.title == sample_trend_data.title
    assert item.created_at is not None
    assert item.updated_at is not None

    # Verify listing
    items = await repo.list_saved_trends(user_id=user)
    assert len(items) == 1
    assert items[0].trend_id == sample_trend_data.trend_id


@pytest.mark.anyio
async def test_prevent_duplicate_saved_trends(repo, sample_trend_data):
    """Test that saving the same trend twice for the same user raises DuplicateTrendError."""
    user = "test-creator-dup"
    await repo.save_trend(user_id=user, trend=sample_trend_data)

    with pytest.raises(DuplicateTrendError):
        await repo.save_trend(user_id=user, trend=sample_trend_data)


@pytest.mark.anyio
async def test_remove_saved_trend(repo, sample_trend_data):
    """Test removing a saved trend."""
    user = "test-creator-remove"
    await repo.save_trend(user_id=user, trend=sample_trend_data)

    # Check saved status
    assert await repo.is_trend_saved(user_id=user, trend_id=sample_trend_data.trend_id) is True

    # Remove trend
    removed = await repo.remove_saved_trend(user_id=user, trend_id=sample_trend_data.trend_id)
    assert removed is True

    # Verify no longer saved
    assert await repo.is_trend_saved(user_id=user, trend_id=sample_trend_data.trend_id) is False
    items = await repo.list_saved_trends(user_id=user)
    assert len(items) == 0

    # Removing again returns False
    removed_again = await repo.remove_saved_trend(user_id=user, trend_id=sample_trend_data.trend_id)
    assert removed_again is False


@pytest.mark.anyio
async def test_user_preferences_persistence(repo):
    """Test setting and updating creator preferences."""
    user = "test-creator-pref"
    
    # Initial save
    prefs = UserPreferencesUpdate(
        niche="Creator Economy",
        audience="YouTubers & Video Editors",
        preferred_platform="YouTube"
    )
    saved_pref = await repo.save_user_preferences(user_id=user, prefs=prefs)
    assert saved_pref.niche == "Creator Economy"
    assert saved_pref.preferred_platform == "YouTube"

    # Fetch
    fetched = await repo.get_user_preferences(user_id=user)
    assert fetched is not None
    assert fetched.audience == "YouTubers & Video Editors"

    # Update niche only
    updated = await repo.save_user_preferences(user_id=user, prefs=UserPreferencesUpdate(niche="AI Tools for Creators"))
    assert updated.niche == "AI Tools for Creators"
    assert updated.preferred_platform == "YouTube"


@pytest.mark.anyio
async def test_supabase_outage_circuit_breaker_fallback(sample_trend_data):
    """
    Simulate a network outage or 500 error from Supabase.
    Verify the repository gracefully catches the error and falls back to local demo storage.
    """
    supabase_repo = SupabaseStorageRepository(
        supabase_url="https://mock-outage-project.supabase.co",
        supabase_key="mock-key-123",
        timeout_seconds=2
    )

    # When Supabase throws an httpx error or network failure
    with patch("httpx.AsyncClient.post", side_effect=Exception("Connection refused / 503 Outage")):
        # Must not raise an unhandled exception; must save to fallback repo
        saved = await supabase_repo.save_trend(user_id="outage-user", trend=sample_trend_data)
        assert saved.trend_id == sample_trend_data.trend_id
        assert saved.user_id == "outage-user"

    with patch("httpx.AsyncClient.get", side_effect=Exception("Database cluster unreachable")):
        # Must gracefully list from fallback repo
        items = await supabase_repo.list_saved_trends(user_id="outage-user")
        assert len(items) == 1
        assert items[0].trend_id == sample_trend_data.trend_id


# ==============================================================================
# FastAPI Endpoint Integration Tests
# ==============================================================================

def test_api_save_trend_endpoint():
    """Test POST /api/saved-trends."""
    payload = {
        "trend_id": "trend-api-test",
        "title": "Autonomous Coding Loops",
        "category": "Tech & AI",
        "platform": "GitHub",
        "velocity": 180,
        "volume": "12.4K stars",
        "sentiment": "positive",
        "source_url": "https://github.com",
        "notes": "Feature in weekly roundup."
    }
    response = client.post(
        "/api/saved-trends",
        json=payload,
        headers={"X-User-ID": "user-integration-test"}
    )
    assert response.status_code == 201
    data = response.json()
    assert data["trend_id"] == "trend-api-test"
    assert data["user_id"] == "user-integration-test"
    assert "id" in data
    assert "created_at" in data

    # Test Duplicate prevention returns 409
    res_dup = client.post(
        "/api/saved-trends",
        json=payload,
        headers={"X-User-ID": "user-integration-test"}
    )
    assert res_dup.status_code == 409
    assert "already saved" in res_dup.json()["detail"].lower()


def test_api_list_saved_trends_endpoint():
    """Test GET /api/saved-trends."""
    response = client.get(
        "/api/saved-trends",
        headers={"X-User-ID": "user-integration-test"}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["total"] >= 1
    assert any(item["trend_id"] == "trend-api-test" for item in data["items"])
    assert "storage_backend" in data


def test_api_check_saved_status_endpoint():
    """Test GET /api/saved-trends/{trend_id}/status."""
    res_true = client.get(
        "/api/saved-trends/trend-api-test/status",
        headers={"X-User-ID": "user-integration-test"}
    )
    assert res_true.status_code == 200
    assert res_true.json()["is_saved"] is True

    res_false = client.get(
        "/api/saved-trends/non-existent-trend/status",
        headers={"X-User-ID": "user-integration-test"}
    )
    assert res_false.status_code == 200
    assert res_false.json()["is_saved"] is False


def test_api_remove_saved_trend_endpoint():
    """Test DELETE /api/saved-trends/{trend_id}."""
    response = client.delete(
        "/api/saved-trends/trend-api-test",
        headers={"X-User-ID": "user-integration-test"}
    )
    assert response.status_code == 200
    assert response.json()["deleted"] is True

    # Deleting again returns 404
    res_404 = client.delete(
        "/api/saved-trends/trend-api-test",
        headers={"X-User-ID": "user-integration-test"}
    )
    assert res_404.status_code == 404


def test_api_user_preferences_endpoints():
    """Test GET and PUT /api/saved-trends/user/preferences."""
    pref_payload = {
        "niche": "Generative AI Video",
        "audience": "Short-Form Creators",
        "preferred_platform": "TikTok"
    }
    # Update preferences
    res_put = client.put(
        "/api/saved-trends/user/preferences",
        json=pref_payload,
        headers={"X-User-ID": "user-pref-test"}
    )
    assert res_put.status_code == 200
    data = res_put.json()
    assert data["niche"] == "Generative AI Video"
    assert data["preferred_platform"] == "TikTok"

    # Get preferences
    res_get = client.get(
        "/api/saved-trends/user/preferences",
        headers={"X-User-ID": "user-pref-test"}
    )
    assert res_get.status_code == 200
    assert res_get.json()["niche"] == "Generative AI Video"


def test_health_check_reports_storage_backend():
    """Verify GET /api/health includes storage backend visibility."""
    res = client.get("/api/health")
    assert res.status_code == 200
    data = res.json()
    assert "storage_backend" in data
    assert "supabase_configured" in data
