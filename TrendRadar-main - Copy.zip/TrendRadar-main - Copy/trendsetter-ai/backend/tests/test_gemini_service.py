import json
import pytest
from unittest.mock import MagicMock
from fastapi.testclient import TestClient
from main import app
from app.models.schemas import (
    TrendItem,
    TrendAnalyzeRequest,
    ContentGenerateRequest,
    TrendAnalysisResult,
    ContentGenerationResult,
    OpportunityScore
)
from app.services.gemini_service import GeminiTrendAIService, get_gemini_service
from app.services.opportunity_scorer import OpportunityScorer

client = TestClient(app)

@pytest.fixture
def sample_trend() -> TrendItem:
    return TrendItem(
        id="trend-test-01",
        title="Agentic Reasoning Loops in Production",
        description="Software engineers discussing self-healing AI agent loops and autonomous tool invocation in production environments.",
        category="Tech & AI",
        platform="Hacker News",
        velocity=320,
        volume="85K mentions",
        sentiment="positive",
        tags=["AIAgents", "DevOps", "Python"],
        source_url="https://news.ycombinator.com/item?id=12345",
        first_detected="2 hours ago",
        raw_score=92
    )

@pytest.fixture
def sparse_trend() -> TrendItem:
    return TrendItem(
        id="trend-sparse-02",
        title="New Widget",
        description="Brief mention.",
        category="Pop Culture",
        platform="X",
        velocity=45,
        volume="12 posts",
        sentiment="neutral",
        tags=[],
        source_url=None,
        first_detected="10 minutes ago"
    )

class MockGeminiClient:
    """Mock Gemini client implementing generate_content for testing."""
    def __init__(self, response_text: str = "", should_raise: Exception = None):
        self.response_text = response_text
        self.should_raise = should_raise
        self.call_count = 0

    def generate_content(self, prompt: str):
        self.call_count += 1
        if self.should_raise:
            raise self.should_raise
        mock_resp = MagicMock()
        mock_resp.text = self.response_text
        return mock_resp


# ==============================================================================
# Unit Tests for GeminiTrendAIService with Mock Client
# ==============================================================================

@pytest.mark.anyio
async def test_ai_service_analyze_trend_all_8_capabilities(sample_trend):
    """
    Verify all 8 capabilities, strict grounding, and that the deterministic Opportunity Engine
    score is preserved and not altered by Gemini.
    """
    mock_payload = {
        "observed_facts": {
            "metrics_summary": "Origin: Hacker News with 85K mentions, velocity +320%, positive sentiment.",
            "source_links": ["https://news.ycombinator.com/item?id=12345"],
            "evidence_snippets": ["Software engineers discussing self-healing AI agent loops"],
            "is_evidence_sufficient": True,
            "evidence_limitations": "Telemetry verified via Hacker News submission link."
        },
        "interpretations": {
            "growth_catalysts": "Surge in autonomous coding frameworks and production reliability needs.",
            "evidence_summary": "High interest in moving from brittle DAGs to self-correcting agent architectures.",
            "intended_audience": ["Senior AI Engineers", "Staff DevOps", "CTOs"],
            "target_niche": "Autonomous Agent Systems",
            "keywords_and_topics": ["AgenticAI", "SelfHealingCode", "ToolCalling"],
            "saturation_and_competition_risks": "Early wave with intense technical interest; low content fatigue so far.",
            "practical_recommended_action": "Publish an architectural teardown comparing deterministic pipelines with agent loops."
        }
    }
    mock_client = MockGeminiClient(response_text=json.dumps(mock_payload))
    service = GeminiTrendAIService(client=mock_client, model_name="gemini-2.5-flash")

    result = await service.analyze_trend(sample_trend)

    # 1. Verify Pydantic validation
    assert isinstance(result, TrendAnalysisResult)
    assert result.provider == "gemini"
    assert not result.is_fallback

    # 2. Verify separation of observed facts from interpretations
    assert result.observed_facts.source_links == ["https://news.ycombinator.com/item?id=12345"]
    assert result.observed_facts.is_evidence_sufficient is True
    assert "Hacker News" in result.observed_facts.metrics_summary

    # 3. Verify Capability 1: Growth catalysts
    assert "Surge in autonomous coding" in result.interpretations.growth_catalysts

    # 4. Verify Capability 2: Evidence summary
    assert "High interest" in result.interpretations.evidence_summary

    # 5. Verify Capability 3: Audience & Niche
    assert "Senior AI Engineers" in result.interpretations.intended_audience
    assert result.interpretations.target_niche == "Autonomous Agent Systems"

    # 6. Verify Capability 4: Keywords & Topics
    assert "AgenticAI" in result.interpretations.keywords_and_topics

    # 7. Verify Capability 7: Saturation & Competition Risks
    assert "Early wave" in result.interpretations.saturation_and_competition_risks

    # 8. Verify Capability 8: Practical recommended action for creator
    assert "Publish an architectural teardown" in result.interpretations.practical_recommended_action

    # 9. Verify Deterministic Opportunity Engine score is preserved
    expected_score = OpportunityScorer.calculate_score(sample_trend)
    assert result.opportunity_score.overall_score == expected_score.overall_score
    assert result.opportunity_score.reach_potential == expected_score.reach_potential
    assert result.opportunity_score.monetization_score == expected_score.monetization_score


@pytest.mark.anyio
async def test_gemini_cannot_alter_deterministic_opportunity_score(sample_trend):
    """
    Ensure that even if Gemini returns a rogue score in its output, the AI service
    strictly retains the Opportunity Engine's deterministic mathematical score.
    """
    mock_payload = {
        "observed_facts": {
            "metrics_summary": "Summary",
            "source_links": ["https://news.ycombinator.com/item?id=12345"],
            "evidence_snippets": ["Test"],
            "is_evidence_sufficient": True,
            "evidence_limitations": "None"
        },
        "interpretations": {
            "growth_catalysts": "Catalyst",
            "evidence_summary": "Summary",
            "intended_audience": ["Engineers"],
            "target_niche": "AI",
            "keywords_and_topics": ["AI"],
            "saturation_and_competition_risks": "Low",
            "practical_recommended_action": "Action"
        },
        # Rogue score attempting to override deterministic engine
        "opportunity_score": {
            "reach_potential": 1,
            "engagement_depth": 1,
            "monetization_score": 1,
            "execution_speed": 1,
            "overall_score": 1,
            "recommendation": "Fake",
            "rationale": "Fake"
        }
    }
    mock_client = MockGeminiClient(response_text=json.dumps(mock_payload))
    service = GeminiTrendAIService(client=mock_client)

    result = await service.analyze_trend(sample_trend)

    deterministic = OpportunityScorer.calculate_score(sample_trend)
    # The score must NOT be 1; it must match the deterministic engine
    assert result.opportunity_score.overall_score == deterministic.overall_score
    assert result.opportunity_score.overall_score > 70


@pytest.mark.anyio
async def test_ai_service_filters_unverified_hallucinated_source_urls(sample_trend):
    """
    Verify that if the model returns hallucinated URLs not present in the trend evidence,
    they are strictly filtered out from observed_facts.
    """
    mock_payload = {
        "observed_facts": {
            "metrics_summary": "Observed summary",
            # One verified URL and two hallucinated URLs
            "source_links": [
                "https://news.ycombinator.com/item?id=12345",
                "https://hallucinated-fake-site.com/metric-spike",
                "https://invented-citation.org/paper.pdf"
            ],
            "evidence_snippets": ["Snippet"],
            "is_evidence_sufficient": True,
            "evidence_limitations": "None"
        },
        "interpretations": {
            "growth_catalysts": "Catalyst",
            "evidence_summary": "Summary",
            "intended_audience": ["Engineers"],
            "target_niche": "Tech",
            "keywords_and_topics": ["AI"],
            "saturation_and_competition_risks": "Low",
            "practical_recommended_action": "Action"
        }
    }
    mock_client = MockGeminiClient(response_text=json.dumps(mock_payload))
    service = GeminiTrendAIService(client=mock_client)

    result = await service.analyze_trend(sample_trend)

    # Hallucinated URLs must be stripped out
    assert result.observed_facts.source_links == ["https://news.ycombinator.com/item?id=12345"]
    assert "https://hallucinated-fake-site.com/metric-spike" not in result.observed_facts.source_links


@pytest.mark.anyio
async def test_ai_service_explicitly_marks_insufficient_evidence(sparse_trend):
    """
    Verify that sparse evidence without external URLs is explicitly marked insufficient.
    """
    service = GeminiTrendAIService(client=None)  # Uses heuristic fallback
    result = await service.analyze_trend(sparse_trend)

    assert result.observed_facts.is_evidence_sufficient is False
    assert "without an external verification URL" in result.observed_facts.evidence_limitations or "Evidence is extremely sparse" in result.observed_facts.evidence_limitations
    assert result.observed_facts.source_links == []


@pytest.mark.anyio
async def test_ai_service_content_generation_all_platforms(sample_trend):
    """
    Verify Capability 5 & 6: Suggests content ideas for YouTube, Instagram, LinkedIn, and Blogs
    with titles, hooks, outlines, and calls to action.
    """
    mock_items = [
        {
            "platform": "YouTube",
            "title": "Why Autonomous Agents Are Breaking Traditional DevOps",
            "hook": "90% of engineers building AI agents are making this fatal production mistake...",
            "angle": "Architectural Deep Dive & Live Benchmark",
            "outline": ["0:00 Hook", "1:00 DAGs vs Loops", "3:30 Live Demo", "5:00 Summary"],
            "call_to_action": "Subscribe and comment 'CODE' for the GitHub repo link."
        },
        {
            "platform": "Instagram",
            "title": "The End of Traditional Zapier Zaps?",
            "hook": "Stop writing hardcoded automation chains: self-healing AI agents just landed in production.",
            "angle": "5-Slide Visual Infographic Carousel",
            "outline": ["Slide 1: Problem", "Slide 2: Agent loop", "Slide 3: Impact", "Slide 4: Action"],
            "call_to_action": "Save this reel and share with your tech lead."
        },
        {
            "platform": "LinkedIn",
            "title": "From Workflows to Autonomous Reasoning: The 2026 Production Shift",
            "hook": "The biggest shift in software architecture this quarter isn't bigger LLMs—it's execution autonomy.",
            "angle": "Executive Technology Strategy Post",
            "outline": ["1. Current Bottleneck", "2. Architectural Pattern", "3. Strategic Decision", "4. Takeaway"],
            "call_to_action": "What is your team's approach to autonomous runtime agents? Join the discussion below."
        },
        {
            "platform": "Blog",
            "title": "Building Production-Grade AI Agent Loops: A Complete Engineering Guide",
            "hook": "Deploying reasoning loops into production requires rethinking state management, telemetry, and error loops.",
            "angle": "Comprehensive Technical Guide & Playbook",
            "outline": ["Introduction", "Architecture Diagram", "Telemetry Strategy", "Deployment Checklist"],
            "call_to_action": "Subscribe to our technical engineering newsletter for weekly deep dives."
        }
    ]
    mock_client = MockGeminiClient(response_text=json.dumps(mock_items))
    service = GeminiTrendAIService(client=mock_client)

    req = ContentGenerateRequest(
        trend_id=sample_trend.id,
        platforms=["YouTube", "Instagram", "LinkedIn", "Blog"]
    )
    result = await service.generate_content(sample_trend, req)

    assert isinstance(result, ContentGenerationResult)
    assert result.provider == "gemini"
    assert len(result.content_by_platform) == 4

    platforms = {item.platform for item in result.content_by_platform}
    assert platforms == {"YouTube", "Instagram", "LinkedIn", "Blog"}

    for item in result.content_by_platform:
        assert item.title and len(item.title) > 5
        assert item.hook and len(item.hook) > 5
        assert item.outline and len(item.outline) >= 3
        assert item.call_to_action and len(item.call_to_action) > 5


@pytest.mark.anyio
async def test_ai_service_caching_prevents_duplicate_api_calls(sample_trend):
    """
    Verify in-memory caching prevents duplicate Gemini API invocations within TTL window.
    """
    mock_payload = {
        "observed_facts": {
            "metrics_summary": "Summary",
            "source_links": [],
            "evidence_snippets": ["Snippet"],
            "is_evidence_sufficient": True,
            "evidence_limitations": "None"
        },
        "interpretations": {
            "growth_catalysts": "Catalyst",
            "evidence_summary": "Summary",
            "intended_audience": ["Audience"],
            "target_niche": "Niche",
            "keywords_and_topics": ["Topic"],
            "saturation_and_competition_risks": "Risk",
            "practical_recommended_action": "Action"
        }
    }
    mock_client = MockGeminiClient(response_text=json.dumps(mock_payload))
    service = GeminiTrendAIService(client=mock_client)

    # First call: invokes client
    res1 = await service.analyze_trend(sample_trend)
    assert not res1.cached
    assert mock_client.call_count == 1

    # Second call: served from cache
    res2 = await service.analyze_trend(sample_trend)
    assert res2.cached
    assert mock_client.call_count == 1  # No additional API call made


@pytest.mark.anyio
async def test_ai_service_handles_rate_limit_and_api_errors_gracefully(sample_trend):
    """
    Verify that rate limit exceptions (HTTP 429) and timeouts trigger graceful labeled fallback.
    """
    mock_client = MockGeminiClient(should_raise=RuntimeError("ResourceExhausted: 429 Quota Exceeded"))
    service = GeminiTrendAIService(client=mock_client)

    result = await service.analyze_trend(sample_trend)

    # Must not raise an exception; must gracefully return fallback
    assert result.is_fallback is True
    assert result.provider == "fallback-heuristic"
    assert "Gemini API error (RuntimeError)" in result.fallback_reason
    assert result.observed_facts is not None
    assert result.interpretations is not None
    assert result.opportunity_score is not None


# ==============================================================================
# FastAPI Integration Endpoint Tests
# ==============================================================================

def test_api_trends_analyze_with_trend_id():
    """Test POST /api/trends/analyze with existing trend_id."""
    response = client.post("/api/trends/analyze", json={"trend_id": "trend-01"})
    assert response.status_code == 200
    data = response.json()

    assert data["trend_id"] == "trend-01"
    assert "observed_facts" in data
    assert "interpretations" in data
    assert "opportunity_score" in data
    assert data["opportunity_score"]["overall_score"] > 0
    assert "provider" in data
    assert "is_fallback" in data


def test_api_trends_analyze_with_custom_inline_trend():
    """Test POST /api/trends/analyze with custom inline trend object."""
    custom_trend = {
        "id": "custom-100",
        "title": "Quantum Error Mitigation on Edge Devices",
        "description": "Researchers publish benchmarking data for quantum noise reduction algorithms.",
        "category": "Tech & AI",
        "platform": "arXiv",
        "velocity": 240,
        "volume": "1.2K papers",
        "sentiment": "positive",
        "tags": ["Quantum", "Physics", "Algorithms"],
        "source_url": "https://arxiv.org/abs/2601.12345",
        "first_detected": "1 hour ago"
    }
    response = client.post("/api/trends/analyze", json={"trend": custom_trend})
    assert response.status_code == 200
    data = response.json()

    assert data["trend_id"] == "custom-100"
    assert data["topic"] == "Quantum Error Mitigation on Edge Devices"
    assert data["observed_facts"]["source_links"] == ["https://arxiv.org/abs/2601.12345"]
    assert "interpretations" in data


def test_api_trends_analyze_missing_input():
    """Test POST /api/trends/analyze with no trend_id and no trend returns 400."""
    response = client.post("/api/trends/analyze", json={})
    assert response.status_code == 400
    assert "Must provide either" in response.json()["detail"]


def test_api_trends_analyze_not_found():
    """Test POST /api/trends/analyze with non-existent trend_id returns 404."""
    response = client.post("/api/trends/analyze", json={"trend_id": "non-existent-999"})
    assert response.status_code == 404


def test_api_content_generate_with_trend_id():
    """Test POST /api/content/generate for YouTube, Instagram, LinkedIn, and Blog."""
    response = client.post("/api/content/generate", json={
        "trend_id": "trend-01",
        "platforms": ["YouTube", "Instagram", "LinkedIn", "Blog"],
        "target_audience": "Tech Founders & Engineers",
        "tone": "Direct, contrarian, actionable"
    })
    assert response.status_code == 200
    data = response.json()

    assert data["trend_id"] == "trend-01"
    assert "content_by_platform" in data
    assert len(data["content_by_platform"]) == 4

    platforms = [item["platform"] for item in data["content_by_platform"]]
    assert "YouTube" in platforms
    assert "Instagram" in platforms
    assert "LinkedIn" in platforms
    assert "Blog" in platforms

    for item in data["content_by_platform"]:
        assert "title" in item and len(item["title"]) > 0
        assert "hook" in item and len(item["hook"]) > 0
        assert "outline" in item and len(item["outline"]) > 0
        assert "call_to_action" in item and len(item["call_to_action"]) > 0


def test_api_content_generate_missing_input():
    """Test POST /api/content/generate with no input returns 400."""
    response = client.post("/api/content/generate", json={})
    assert response.status_code == 400


def test_secrets_never_exposed_in_api_responses():
    """
    Ensure GEMINI_API_KEY is NEVER leaked in any API endpoint responses.
    """
    from config import settings
    secret = settings.GEMINI_API_KEY
    if not secret:
        secret = "super_secret_test_key_123456"

    # Check health
    res_health = client.get("/api/health")
    assert secret not in res_health.text
    assert "gemini_configured" in res_health.json()

    # Check analyze
    res_analyze = client.post("/api/trends/analyze", json={"trend_id": "trend-01"})
    assert secret not in res_analyze.text

    # Check content
    res_content = client.post("/api/content/generate", json={"trend_id": "trend-01"})
    assert secret not in res_content.text
