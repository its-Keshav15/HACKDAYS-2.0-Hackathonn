import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_root_endpoint():
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert data["project"] == "TrendSetter AI"
    assert data["status"] == "online"

def test_health_check():
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert "gemini_configured" in data

def test_list_trends():
    response = client.get("/api/trends")
    assert response.status_code == 200
    data = response.json()
    assert data["total"] > 0
    assert len(data["trends"]) > 0
    assert "categories" in data
    assert "platforms" in data

def test_filter_trends_by_category():
    response = client.get("/api/trends?category=Tech %26 AI")
    assert response.status_code == 200
    data = response.json()
    for trend in data["trends"]:
        assert trend["category"] == "Tech & AI"

def test_get_single_trend():
    response = client.get("/api/trends/trend-01")
    assert response.status_code == 200
    data = response.json()
    assert data["id"] == "trend-01"
    assert "velocity" in data

def test_get_opportunity_score():
    response = client.get("/api/trends/trend-01/score")
    assert response.status_code == 200
    data = response.json()
    assert 0 <= data["overall_score"] <= 100
    assert "recommendation" in data

def test_generate_content_ideas():
    response = client.get("/api/trends/trend-01/ideas")
    assert response.status_code == 200
    data = response.json()
    assert data["trend_id"] == "trend-01"
    assert len(data["ideas"]) > 0
    assert "hook" in data["ideas"][0]
