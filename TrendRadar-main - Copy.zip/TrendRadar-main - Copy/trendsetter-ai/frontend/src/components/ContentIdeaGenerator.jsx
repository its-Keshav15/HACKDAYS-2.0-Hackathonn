import React, { useState, useEffect } from 'react';
import { generateContentIdeas } from '../services/api';

export default function ContentIdeaGenerator({ trend, onClose }) {
  const [ideas, setIdeas] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [copiedIndex, setCopiedIndex] = useState(null);
  
  // Customization options
  const [audience, setAudience] = useState("Creators & Builders");
  const [tone, setTone] = useState("High-Energy, Contrarian & Actionable");

  const handleGenerate = async () => {
    if (!trend) return;
    setLoading(true);
    setError(null);
    try {
      const res = await generateContentIdeas(trend.id, {
        target_audience: audience,
        tone: tone
      });
      setIdeas(res.ideas || []);
    } catch (err) {
      setError(err.message || 'Failed to generate ideas');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (trend) {
      handleGenerate();
    }
  }, [trend]);

  const handleCopy = (idea, idx) => {
    const textToCopy = `[${idea.platform}] - ${idea.angle}\n\nHOOK:\n${idea.hook}\n\nOUTLINE:\n${idea.outline.join('\n')}\n\nCALL TO ACTION:\n${idea.call_to_action}`;
    navigator.clipboard.writeText(textToCopy);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  if (!trend) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" style={{ maxWidth: '820px' }} onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>&times;</button>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
          <span className="badge badge-category">{trend.category}</span>
          <span className="badge badge-platform">+{trend.velocity}% Velocity</span>
        </div>

        <h2 style={{ fontSize: '1.4rem', fontWeight: 800, marginBottom: '0.25rem' }}>
          AI Content Studio: {trend.title}
        </h2>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', marginBottom: '1.5rem' }}>
          Transform real-time trend intelligence into viral hooks, threads, video scripts, and carousels.
        </p>

        {/* Configuration Bar */}
        <div style={{ background: '#0c121e', padding: '1rem', borderRadius: '12px', border: '1px solid var(--border-subtle)', marginBottom: '1.5rem', display: 'flex', flexWrap: 'wrap', gap: '1rem', alignItems: 'center' }}>
          <div style={{ flex: 1, minWidth: '200px' }}>
            <label style={{ display: 'block', fontSize: '0.75rem', color: 'var(--text-dim)', marginBottom: '0.35rem', textTransform: 'uppercase' }}>
              Target Audience
            </label>
            <select 
              value={audience} 
              onChange={(e) => setAudience(e.target.value)}
              style={{ width: '100%', background: 'var(--bg-input)', color: 'var(--text-main)', border: '1px solid var(--border-subtle)', padding: '0.45rem 0.75rem', borderRadius: '8px', fontSize: '0.85rem' }}
            >
              <option value="Creators & Builders">Creators & Builders</option>
              <option value="Founders & Solopreneurs">Founders & Solopreneurs</option>
              <option value="General Consumers & Fans">General Consumers & Fans</option>
              <option value="B2B & Enterprise Leaders">B2B & Enterprise Leaders</option>
            </select>
          </div>

          <div style={{ flex: 1, minWidth: '200px' }}>
            <label style={{ display: 'block', fontSize: '0.75rem', color: 'var(--text-dim)', marginBottom: '0.35rem', textTransform: 'uppercase' }}>
              Tone & Narrative Angle
            </label>
            <select 
              value={tone} 
              onChange={(e) => setTone(e.target.value)}
              style={{ width: '100%', background: 'var(--bg-input)', color: 'var(--text-main)', border: '1px solid var(--border-subtle)', padding: '0.45rem 0.75rem', borderRadius: '8px', fontSize: '0.85rem' }}
            >
              <option value="High-Energy, Contrarian & Actionable">High-Energy, Contrarian & Actionable</option>
              <option value="Educational Step-by-Step Breakdown">Educational Step-by-Step Breakdown</option>
              <option value="Executive Synthesis & Future Outlook">Executive Synthesis & Future Outlook</option>
              <option value="Casual, Relatable Storytelling">Casual, Relatable Storytelling</option>
            </select>
          </div>

          <button 
            className="btn btn-primary" 
            style={{ marginTop: 'auto', alignSelf: 'flex-end', height: '36px' }}
            onClick={handleGenerate}
            disabled={loading}
          >
            {loading ? 'Generating...' : 'Regenerate Ideas'}
          </button>
        </div>

        {loading && (
          <div style={{ textAlign: 'center', padding: '3rem 0' }}>
            <div className="spinner"></div>
            <p style={{ marginTop: '1rem', color: 'var(--text-muted)' }}>Synthesizing multi-platform viral formats with Gemini...</p>
          </div>
        )}

        {error && (
          <div style={{ padding: '1rem', background: 'rgba(239, 68, 68, 0.1)', border: '1px solid rgba(239, 68, 68, 0.3)', borderRadius: '10px', color: '#f87171', marginBottom: '1.5rem' }}>
            {error}
          </div>
        )}

        {!loading && ideas.length > 0 && (
          <div>
            {ideas.map((idea, idx) => (
              <div key={idx} className="idea-card">
                <div className="idea-header">
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <span className="badge" style={{ background: 'rgba(99, 102, 241, 0.2)', color: '#c7d2fe', border: '1px solid rgba(99, 102, 241, 0.4)' }}>
                      {idea.platform}
                    </span>
                    <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)' }}>
                      Angle: {idea.angle}
                    </span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                    <span style={{ fontSize: '0.72rem', color: 'var(--accent-emerald)', fontWeight: 600 }}>
                      Viral Potential: {idea.estimated_viral_factor}
                    </span>
                    <button 
                      className="btn btn-secondary copy-btn"
                      onClick={() => handleCopy(idea, idx)}
                    >
                      {copiedIndex === idx ? '✓ Copied' : 'Copy All'}
                    </button>
                  </div>
                </div>

                <div className="idea-hook">
                  "{idea.hook}"
                </div>

                <ul className="idea-outline">
                  {idea.outline.map((point, pIdx) => (
                    <li key={pIdx}>{point}</li>
                  ))}
                </ul>

                <div style={{ marginTop: '0.75rem', fontSize: '0.8rem', color: 'var(--accent-cyan)', background: 'rgba(6, 182, 212, 0.08)', padding: '0.4rem 0.75rem', borderRadius: '6px' }}>
                  <strong>Call to Action:</strong> {idea.call_to_action}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
