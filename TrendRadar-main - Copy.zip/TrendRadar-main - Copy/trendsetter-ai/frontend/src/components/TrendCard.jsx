import React from 'react';

export default function TrendCard({ trend, onOpenScore, onOpenIdeas }) {
  const getSentimentColor = (sentiment) => {
    switch (sentiment) {
      case 'positive': return 'var(--accent-emerald)';
      case 'controversial': return 'var(--accent-amber)';
      default: return 'var(--text-muted)';
    }
  };

  return (
    <div className="trend-card">
      <div>
        <div className="card-top">
          <div className="tag-badges">
            <span className="badge badge-category">{trend.category}</span>
            <span className="badge badge-platform">{trend.platform}</span>
          </div>
          <div className="velocity-indicator">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline>
              <polyline points="17 6 23 6 23 12"></polyline>
            </svg>
            +{trend.velocity}%
          </div>
        </div>

        <h3 className="trend-title">{trend.title}</h3>
        <p className="trend-description">{trend.description}</p>

        <div className="trend-metrics">
          <div className="metric-item">
            <span className="metric-label">Volume</span>
            <span className="metric-val">{trend.volume}</span>
          </div>
          <div className="metric-item">
            <span className="metric-label">Sentiment</span>
            <span className="metric-val" style={{ color: getSentimentColor(trend.sentiment), textTransform: 'capitalize' }}>
              {trend.sentiment}
            </span>
          </div>
          <div className="metric-item">
            <span className="metric-label">Detected</span>
            <span className="metric-val">{trend.first_detected}</span>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap', marginBottom: '1.25rem' }}>
          {trend.tags?.map(tag => (
            <span key={tag} style={{ fontSize: '0.72rem', color: 'var(--text-dim)', background: 'var(--bg-input)', padding: '0.15rem 0.45rem', borderRadius: '4px' }}>
              #{tag}
            </span>
          ))}
        </div>
      </div>

      <div className="card-actions">
        <button 
          className="btn btn-secondary" 
          style={{ flex: 1 }}
          onClick={() => onOpenScore(trend)}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 20v-6M6 20V10M18 20V4"/>
          </svg>
          Opportunity Score
        </button>

        <button 
          className="btn btn-primary" 
          style={{ flex: 1 }}
          onClick={() => onOpenIdeas(trend)}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
          </svg>
          AI Studio
        </button>
      </div>
    </div>
  );
}
