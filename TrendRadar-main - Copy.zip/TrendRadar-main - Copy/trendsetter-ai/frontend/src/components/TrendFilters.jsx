import React from 'react';

export default function TrendFilters({
  search,
  setSearch,
  category,
  setCategory,
  categories,
  platform,
  setPlatform,
  platforms
}) {
  return (
    <div className="controls-bar">
      <div className="search-row">
        <div className="search-input-wrapper">
          <svg className="search-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="11" cy="11" r="8"></circle>
            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
          </svg>
          <input
            type="text"
            className="search-input"
            placeholder="Search topics, keywords, tags, or platforms..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="filters-row">
        <div className="filter-group">
          <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)', marginRight: '0.25rem' }}>Category:</span>
          <button
            className={`filter-chip ${category === 'All' ? 'active' : ''}`}
            onClick={() => setCategory('All')}
          >
            All Categories
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              className={`filter-chip ${category === cat ? 'active' : ''}`}
              onClick={() => setCategory(cat)}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="filter-group">
          <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)', marginRight: '0.25rem' }}>Platform:</span>
          <button
            className={`filter-chip ${platform === 'All' ? 'active' : ''}`}
            onClick={() => setPlatform('All')}
          >
            All
          </button>
          {platforms.map((plat) => (
            <button
              key={plat}
              className={`filter-chip ${platform === plat ? 'active' : ''}`}
              onClick={() => setPlatform(plat)}
            >
              {plat}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
