import React, { useEffect, useState } from 'react';
import { analyzeTrend } from '../services/api';

export default function OpportunityModal({ trend, onClose, onSwitchToIdeas }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!trend) return;
    let isMounted = true;
    setLoading(true);
    setError(null);

    analyzeTrend(trend.id)
      .then((res) => {
        if (isMounted) {
          setData(res);
          setLoading(false);
        }
      })
      .catch((err) => {
        if (isMounted) {
          setError(err.message || 'Failed to analyze trend');
          setLoading(false);
        }
      });

    return () => { isMounted = false; };
  }, [trend]);

  if (!trend) return null;

  const score = data?.opportunity_score;
  const analysis = data?.analysis;
  const overall = score?.overall_score || 0;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>&times;</button>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
          <span className="badge badge-category">{trend.category}</span>
          <span className="badge badge-platform">{trend.platform}</span>
          {data?.generated_by && (
            <span style={{ fontSize: '0.72rem', color: 'var(--text-dim)', marginLeft: 'auto' }}>
              Engine: {data.generated_by}
            </span>
          )}
        </div>

        <h2 style={{ fontSize: '1.4rem', fontWeight: 800, marginBottom: '0.5rem' }}>{trend.title}</h2>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>{trend.description}</p>

        {loading && (
          <div style={{ textAlign: 'center', padding: '3rem 0' }}>
            <div className="spinner"></div>
            <p style={{ marginTop: '1rem', color: 'var(--text-muted)' }}>Running Gemini AI Opportunity Engine...</p>
          </div>
        )}

        {error && (
          <div style={{ margin: '1.5rem 0', padding: '1rem', background: 'rgba(239, 68, 68, 0.1)', border: '1px solid rgba(239, 68, 68, 0.3)', borderRadius: '10px', color: '#f87171' }}>
            {error}
          </div>
        )}

        {!loading && score && (
          <>
            <div className="score-hero">
              <div className="score-circle" style={{ '--score-pct': overall }}>
                <div className="score-circle-inner">
                  <span className="score-number">{overall}</span>
                  <span className="score-max">/ 100</span>
                </div>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: '0.75rem', textTransform: 'uppercase', color: 'var(--accent-emerald)', fontWeight: 700, letterSpacing: '0.05em' }}>
                  Opportunity Diagnosis
                </div>
                <h4 style={{ fontSize: '1.1rem', fontWeight: 700, margin: '0.3rem 0' }}>
                  {score.recommendation}
                </h4>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
                  {score.rationale}
                </p>
              </div>
            </div>

            <div className="score-breakdown-grid">
              <div className="breakdown-bar-item">
                <div className="bar-header">
                  <span>Reach Potential</span>
                  <span style={{ fontWeight: 700 }}>{score.reach_potential}%</span>
                </div>
                <div className="bar-track">
                  <div className="bar-fill" style={{ width: `${score.reach_potential}%` }}></div>
                </div>
              </div>

              <div className="breakdown-bar-item">
                <div className="bar-header">
                  <span>Audience Engagement</span>
                  <span style={{ fontWeight: 700 }}>{score.engagement_depth}%</span>
                </div>
                <div className="bar-track">
                  <div className="bar-fill" style={{ width: `${score.engagement_depth}%` }}></div>
                </div>
              </div>

              <div className="breakdown-bar-item">
                <div className="bar-header">
                  <span>Monetization Viability</span>
                  <span style={{ fontWeight: 700 }}>{score.monetization_score}%</span>
                </div>
                <div className="bar-track">
                  <div className="bar-fill" style={{ width: `${score.monetization_score}%` }}></div>
                </div>
              </div>

              <div className="breakdown-bar-item">
                <div className="bar-header">
                  <span>Execution Speed</span>
                  <span style={{ fontWeight: 700 }}>{score.execution_speed}%</span>
                </div>
                <div className="bar-track">
                  <div className="bar-fill" style={{ width: `${score.execution_speed}%` }}></div>
                </div>
              </div>
            </div>

            {analysis && (
              <div style={{ marginTop: '1.5rem', background: '#0c121e', padding: '1.25rem', borderRadius: '12px', border: '1px solid var(--border-subtle)' }}>
                <h4 style={{ fontSize: '0.95rem', fontWeight: 700, marginBottom: '0.5rem', color: 'var(--accent-cyan)' }}>
                  Gemini Deep Trend Intelligence
                </h4>
                
                <div style={{ marginBottom: '0.75rem' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)', textTransform: 'uppercase' }}>Why It's Trending</div>
                  <div style={{ fontSize: '0.85rem', color: 'var(--text-main)', marginTop: '0.15rem' }}>{analysis.why_trending}</div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '0.75rem', marginBottom: '0.75rem' }}>
                  <div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)', textTransform: 'uppercase' }}>Longevity Outlook</div>
                    <div style={{ fontSize: '0.85rem', fontWeight: 600, color: '#f1f5f9' }}>{analysis.longevity_outlook}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)', textTransform: 'uppercase' }}>Saturation Level</div>
                    <div style={{ fontSize: '0.85rem', fontWeight: 600, color: '#f1f5f9' }}>{analysis.saturation_level}</div>
                  </div>
                </div>

                <div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)', textTransform: 'uppercase' }}>Target Audience Demographic</div>
                  <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap', marginTop: '0.25rem' }}>
                    {analysis.target_audience?.map((aud) => (
                      <span key={aud} style={{ fontSize: '0.75rem', background: 'var(--bg-input)', padding: '0.2rem 0.5rem', borderRadius: '4px' }}>
                        {aud}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            )}

            <div style={{ marginTop: '1.5rem', display: 'flex', justifyContent: 'flex-end', gap: '0.75rem' }}>
              <button className="btn btn-secondary" onClick={onClose}>
                Close
              </button>
              <button 
                className="btn btn-primary" 
                onClick={() => {
                  onClose();
                  onSwitchToIdeas(trend);
                }}
              >
                Generate Content Ideas in AI Studio &rarr;
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
