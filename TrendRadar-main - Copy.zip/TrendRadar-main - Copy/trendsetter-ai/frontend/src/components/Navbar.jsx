import React from 'react';

export default function Navbar({ health, onRefresh, loading }) {
  const isGeminiActive = health?.gemini_configured;

  return (
    <header className="navbar">
      <div className="brand-wrapper">
        <div className="brand-logo">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="22 7 13.5 15.5 8.5 10.5 2 17"></polyline>
            <polyline points="16 7 22 7 22 13"></polyline>
          </svg>
        </div>
        <div>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <span className="brand-title">TrendSetter AI</span>
            <span className="badge-hackathon">Hackathon MVP</span>
          </div>
        </div>
      </div>

      <div className="nav-status">
        <div className={`status-indicator ${isGeminiActive ? '' : 'mock'}`}>
          <div className="status-dot"></div>
          <span>{isGeminiActive ? 'Gemini 1.5 Active' : 'AI Mock Mode'}</span>
        </div>

        <button 
          className="btn btn-secondary" 
          onClick={onRefresh}
          disabled={loading}
          title="Refresh trending topics"
        >
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ transform: loading ? 'rotate(180deg)' : 'none', transition: 'transform 0.5s ease' }}>
            <path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/>
          </svg>
          {loading ? 'Refreshing...' : 'Refresh Feed'}
        </button>
      </div>
    </header>
  );
}
