import React from 'react';

export default function StatsOverview({ trends }) {
  const total = trends.length;
  
  // Highest velocity calculation
  const topVelocity = total > 0 ? Math.max(...trends.map(t => t.velocity)) : 0;
  
  // Category distribution
  const topCategory = total > 0 ? trends[0]?.category : 'Tech & AI';
  
  // Average baseline score
  const avgVelocity = total > 0 ? Math.round(trends.reduce((acc, t) => acc + t.velocity, 0) / total) : 0;

  return (
    <div className="stats-grid">
      <div className="stat-card">
        <div className="stat-label">Tracked Viral Topics</div>
        <div className="stat-value">{total}</div>
        <div className="stat-subtitle">Across 5+ major platforms</div>
      </div>

      <div className="stat-card">
        <div className="stat-label">Peak Velocity Surge</div>
        <div className="stat-value" style={{ color: 'var(--accent-emerald)' }}>+{topVelocity}%</div>
        <div className="stat-subtitle">Leading breakout topic</div>
      </div>

      <div className="stat-card">
        <div className="stat-label">Average Trend Growth</div>
        <div className="stat-value">+{avgVelocity}%</div>
        <div className="stat-subtitle">Rolling 24-hour velocity</div>
      </div>

      <div className="stat-card">
        <div className="stat-label">Top Attention Domain</div>
        <div className="stat-value" style={{ fontSize: '1.4rem', color: 'var(--accent-cyan)' }}>{topCategory}</div>
        <div className="stat-subtitle">High creator conversion</div>
      </div>
    </div>
  );
}
