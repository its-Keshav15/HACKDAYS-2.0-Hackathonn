const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8000/api';

export async function fetchHealth() {
  try {
    const res = await fetch(`${API_BASE}/health`);
    if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn("Backend offline or unreachable:", err);
    return { status: "offline", gemini_configured: false, trend_source_mode: "mock" };
  }
}

export async function fetchTrends(params = {}) {
  const query = new URLSearchParams();
  if (params.category && params.category !== 'All') query.append('category', params.category);
  if (params.platform && params.platform !== 'All') query.append('platform', params.platform);
  if (params.minVelocity) query.append('min_velocity', params.minVelocity);
  if (params.search) query.append('search', params.search);

  const url = `${API_BASE}/trends${query.toString() ? '?' + query.toString() : ''}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to fetch trends: ${res.statusText}`);
  return await res.json();
}

export async function fetchTrendById(trendId) {
  const res = await fetch(`${API_BASE}/trends/${trendId}`);
  if (!res.ok) throw new Error(`Failed to fetch trend details`);
  return await res.json();
}

export async function analyzeTrend(trendId) {
  const res = await fetch(`${API_BASE}/trends/${trendId}/analyze`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  });
  if (!res.ok) throw new Error(`Failed to analyze trend`);
  return await res.json();
}

export async function fetchOpportunityScore(trendId) {
  const res = await fetch(`${API_BASE}/trends/${trendId}/score`);
  if (!res.ok) throw new Error(`Failed to fetch opportunity score`);
  return await res.json();
}

export async function generateContentIdeas(trendId, options = {}) {
  const res = await fetch(`${API_BASE}/trends/${trendId}/ideas`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      target_audience: options.target_audience || "Creators & Tech Enthusiasts",
      tone: options.tone || "High-Energy, Insightful & Actionable",
      custom_angle: options.custom_angle || null
    })
  });
  if (!res.ok) throw new Error(`Failed to generate content ideas`);
  return await res.json();
}

// ==============================================================================
// Saved Trends & User Preferences API Client
// ==============================================================================

export async function fetchSavedTrends() {
  const res = await fetch(`${API_BASE}/saved-trends`);
  if (!res.ok) throw new Error(`Failed to fetch saved trends`);
  return await res.json();
}

export async function saveTrend(trendData) {
  const res = await fetch(`${API_BASE}/saved-trends`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(trendData)
  });
  if (res.status === 409) {
    throw new Error('Trend is already saved in your library');
  }
  if (!res.ok) throw new Error(`Failed to save trend`);
  return await res.json();
}

export async function removeSavedTrend(trendId) {
  const res = await fetch(`${API_BASE}/saved-trends/${trendId}`, {
    method: 'DELETE'
  });
  if (!res.ok) throw new Error(`Failed to remove saved trend`);
  return await res.json();
}

export async function checkTrendSavedStatus(trendId) {
  try {
    const res = await fetch(`${API_BASE}/saved-trends/${trendId}/status`);
    if (!res.ok) return { is_saved: false };
    return await res.json();
  } catch {
    return { is_saved: false };
  }
}

export async function fetchUserPreferences() {
  const res = await fetch(`${API_BASE}/saved-trends/user/preferences`);
  if (!res.ok) return null;
  return await res.json();
}

export async function updateUserPreferences(prefs) {
  const res = await fetch(`${API_BASE}/saved-trends/user/preferences`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(prefs)
  });
  if (!res.ok) throw new Error(`Failed to update preferences`);
  return await res.json();
}
