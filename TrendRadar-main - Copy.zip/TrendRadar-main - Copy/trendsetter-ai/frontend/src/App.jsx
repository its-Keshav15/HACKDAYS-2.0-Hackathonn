import React, { useState, useEffect, useCallback } from 'react';
import Navbar from './components/Navbar';
import StatsOverview from './components/StatsOverview';
import TrendFilters from './components/TrendFilters';
import TrendCard from './components/TrendCard';
import OpportunityModal from './components/OpportunityModal';
import ContentIdeaGenerator from './components/ContentIdeaGenerator';
import { fetchHealth, fetchTrends } from './services/api';

export default function App() {
  const [health, setHealth] = useState(null);
  const [trends, setTrends] = useState([]);
  const [categories, setCategories] = useState([]);
  const [platforms, setPlatforms] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [platform, setPlatform] = useState('All');

  // Active Modals
  const [scoreModalTrend, setScoreModalTrend] = useState(null);
  const [ideasModalTrend, setIdeasModalTrend] = useState(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [healthData, trendsData] = await Promise.all([
        fetchHealth(),
        fetchTrends({ category, platform, search })
      ]);
      setHealth(healthData);
      setTrends(trendsData.trends || []);
      setCategories(trendsData.categories || []);
      setPlatforms(trendsData.platforms || []);
    } catch (err) {
      console.error('Error fetching dashboard data:', err);
    } finally {
      setLoading(false);
    }
  }, [category, platform, search]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  return (
    <div className="app-container">
      <Navbar 
        health={health} 
        onRefresh={loadData} 
        loading={loading} 
      />

      <StatsOverview trends={trends} />

      <TrendFilters
        search={search}
        setSearch={setSearch}
        category={category}
        setCategory={setCategory}
        categories={categories}
        platform={platform}
        setPlatform={setPlatform}
        platforms={platforms}
      />

      {loading && trends.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '4rem 0' }}>
          <div className="spinner"></div>
          <p style={{ marginTop: '1rem', color: 'var(--text-muted)' }}>
            Polling Trend Intelligence sources...
          </p>
        </div>
      ) : trends.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '4rem 2rem', background: 'var(--bg-card)', borderRadius: '16px', border: '1px solid var(--border-subtle)' }}>
          <h3 style={{ fontSize: '1.2rem', marginBottom: '0.5rem' }}>No trending topics found</h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginBottom: '1.5rem' }}>
            No topics matched your current filter criteria.
          </p>
          <button 
            className="btn btn-secondary"
            onClick={() => {
              setSearch('');
              setCategory('All');
              setPlatform('All');
            }}
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="trends-grid">
          {trends.map((trend) => (
            <TrendCard
              key={trend.id}
              trend={trend}
              onOpenScore={(t) => setScoreModalTrend(t)}
              onOpenIdeas={(t) => setIdeasModalTrend(t)}
            />
          ))}
        </div>
      )}

      {/* Opportunity Analysis Modal */}
      {scoreModalTrend && (
        <OpportunityModal
          trend={scoreModalTrend}
          onClose={() => setScoreModalTrend(null)}
          onSwitchToIdeas={(t) => setIdeasModalTrend(t)}
        />
      )}

      {/* AI Content Studio Modal */}
      {ideasModalTrend && (
        <ContentIdeaGenerator
          trend={ideasModalTrend}
          onClose={() => setIdeasModalTrend(null)}
        />
      )}

      <footer style={{ marginTop: '4rem', paddingTop: '1.5rem', borderTop: '1px solid var(--border-subtle)', textAlign: 'center', color: 'var(--text-dim)', fontSize: '0.825rem' }}>
        TrendSetter AI &bull; Hackathon Edition &bull; Powered by FastAPI & Google Gemini API
      </footer>
    </div>
  );
}
